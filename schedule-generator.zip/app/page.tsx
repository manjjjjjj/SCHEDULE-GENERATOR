"use client"

import { useEffect, useState } from "react"
import Image from "next/image"
import { ScheduleGenerator } from "@/components/schedule-generator"
import { Button } from "@/components/ui/button"
import { LogOut } from "lucide-react"

export default function Home() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check if user is authenticated
    const checkAuth = () => {
      const authStatus = localStorage.getItem("isAuthenticated")
      if (authStatus !== "true") {
        window.location.href = "/login"
      } else {
        setIsAuthenticated(true)
      }
      setIsLoading(false)
    }

    checkAuth()
  }, [])

  const handleLogout = () => {
    localStorage.removeItem("isAuthenticated")
    window.location.href = "/login"
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">Loading...</div>
      </div>
    )
  }

  if (!isAuthenticated) {
    return null // Will redirect in useEffect
  }

  return (
    <main className="container mx-auto py-10 px-4">
      <div className="flex justify-between items-center mb-8 border-b pb-4">
        <div className="school-header">
          <Image
            src="/images/smk-dato-seth-logo.png"
            alt="SMK Dato Seth Logo"
            width={50}
            height={50}
            className="school-logo"
          />
          <div>
            <h1 className="text-3xl font-bold text-primary">SMK Dato Seth</h1>
            <p className="text-sm text-muted-foreground">School Schedule Generator</p>
          </div>
        </div>
        <Button variant="outline" onClick={handleLogout} className="border-primary text-primary hover:bg-primary/10">
          <LogOut className="h-4 w-4 mr-2" />
          Logout
        </Button>
      </div>
      <ScheduleGenerator />
    </main>
  )
}
