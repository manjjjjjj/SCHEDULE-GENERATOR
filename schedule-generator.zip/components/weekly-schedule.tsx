"use client"

import type { ScheduleEntry } from "./schedule-generator"
import { Card, CardContent } from "@/components/ui/card"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

type WeeklyScheduleProps = {
  schedule: ScheduleEntry[]
}

// Update the WeeklySchedule component to show session duration
export function WeeklySchedule({ schedule }: WeeklyScheduleProps) {
  const days = ["monday", "tuesday", "wednesday", "thursday", "friday"]
  const dayLabels = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]

  // Create time slots from 7:30 to 14:00 (7:30am to 2pm)
  const timeSlots = []
  for (let hour = 7; hour <= 14; hour++) {
    const hourStr = hour.toString().padStart(2, "0")
    if (hour === 7) {
      timeSlots.push(`${hourStr}:30`)
    } else {
      timeSlots.push(`${hourStr}:00`)
      if (hour < 14) timeSlots.push(`${hourStr}:30`)
    }
  }

  // Helper function to convert time string to minutes since midnight
  const timeToMinutes = (time: string) => {
    const [hours, minutes] = time.split(":").map(Number)
    return hours * 60 + minutes
  }

  // Helper function to calculate position and height based on start and end times
  const calculatePosition = (startTime: string, endTime: string) => {
    const startMinutes = timeToMinutes(startTime)
    const endMinutes = timeToMinutes(endTime)

    const startHour = 7.5 // Schedule starts at 7:30 (7 hours + 30 minutes)
    const hourHeight = 60 // Each hour is 60px tall

    const top = ((startMinutes - startHour * 60) / 60) * hourHeight
    const height = ((endMinutes - startMinutes) / 60) * hourHeight

    return { top, height }
  }

  // Helper function to calculate session duration in minutes
  const calculateDuration = (startTime: string, endTime: string) => {
    const startMinutes = timeToMinutes(startTime)
    const endMinutes = timeToMinutes(endTime)
    return endMinutes - startMinutes
  }

  // Get classes for a specific day
  const getClassesForDay = (day: string) => {
    return schedule.filter((c) => c.day === day)
  }

  if (schedule.length === 0) {
    return (
      <div className="text-center p-10 border rounded-lg bg-muted/20">
        <p className="text-muted-foreground">No schedule data available.</p>
      </div>
    )
  }

  // Generate colors for each class
  const classColors: Record<string, string> = {}
  schedule.forEach((entry) => {
    if (!classColors[entry.classId]) {
      const hue = Math.floor(Math.random() * 360)
      classColors[entry.classId] = `hsl(${hue}, 70%, 60%)`
    }
  })

  // Mock data for blocks and classItem
  const blocks = [
    { id: "1", name: "Block A" },
    { id: "2", name: "Block B" },
  ]
  const classItem = { block: "1" }

  return (
    <Card className="print:shadow-none">
      <CardContent className="p-4">
        <div className="grid grid-cols-6 gap-2">
          {/* Time column */}
          <div className="pr-2 pt-10">
            {timeSlots.map((time, index) => (
              <div
                key={time}
                className={`h-[30px] text-right text-sm text-muted-foreground ${index % 2 === 0 ? "font-medium" : ""}`}
              >
                {index % 2 === 0 ? time : ""}
              </div>
            ))}
          </div>

          {/* Day columns */}
          {days.map((day, dayIndex) => (
            <div key={day} className="relative">
              <div className="h-10 font-medium text-center border-b">{dayLabels[dayIndex]}</div>

              {/* Time grid lines */}
              <div className="relative h-[390px] border-l">
                {timeSlots.map((time, index) => (
                  <div
                    key={time}
                    className={`absolute w-full ${index % 2 === 0 ? "h-[1px] bg-muted" : "h-[1px] bg-muted/50"}`}
                    style={{ top: `${index * 30}px` }}
                  />
                ))}

                {/* Recess time highlight */}
                <div
                  className="absolute w-full bg-amber-100 border border-amber-200 z-0"
                  style={{
                    top: `${((timeToMinutes("10:30") - timeToMinutes("07:30")) / 60) * 60}px`,
                    height: `${((timeToMinutes("11:00") - timeToMinutes("10:30")) / 60) * 60}px`,
                  }}
                >
                  <div className="h-full flex items-center justify-center">
                    <span className="text-xs text-amber-800 font-medium">Recess</span>
                  </div>
                </div>

                {/* Classes */}
                <TooltipProvider>
                  {getClassesForDay(day).map((entry) => {
                    if (entry.isRecess) return null // Skip rendering recess entries

                    const { top, height } = calculatePosition(entry.startTime, entry.endTime)
                    const color = classColors[entry.classId]
                    const duration = calculateDuration(entry.startTime, entry.endTime)

                    // Check if this is a specialized venue or home room
                    const isSpecializedVenue = entry.subjectCategory !== "normal"

                    // Add a border style based on venue matching
                    const borderStyle = entry.isOptimalVenue ? "border-2" : "border border-dashed"

                    return (
                      <Tooltip key={entry.id}>
                        <TooltipTrigger asChild>
                          <div
                            className={`absolute w-[calc(100%-8px)] left-1 rounded-md p-1 overflow-hidden ${borderStyle} cursor-pointer z-10`}
                            style={{
                              top: `${top}px`,
                              height: `${height}px`,
                              backgroundColor: `${color}20`,
                              borderColor: color,
                            }}
                          >
                            <div className="h-full flex flex-col">
                              <div className="text-xs font-medium truncate" style={{ color }}>
                                {entry.className} - {entry.subjectName}
                              </div>
                              {height > 40 && (
                                <div className="text-xs truncate">
                                  {isSpecializedVenue ? `${entry.venueName} (Special)` : entry.venueName}
                                </div>
                              )}
                              {height > 60 && (
                                <div className="text-xs text-muted-foreground truncate mt-auto">
                                  {entry.teacherName}
                                </div>
                              )}
                            </div>
                          </div>
                        </TooltipTrigger>
                        <TooltipContent>
                          <div className="space-y-1">
                            <p className="font-medium">Class: {entry.className}</p>
                            <p>Subject: {entry.subjectName}</p>
                            <p>Teacher: {entry.teacherName}</p>
                            <p>
                              Location: {entry.venueName} {isSpecializedVenue ? "(Specialized Venue)" : "(Home Room)"}
                            </p>
                            <p>Block: {blocks.find((b) => b.id === classItem?.block)?.name || "Unknown"}</p>
                            <p>
                              Time: {entry.startTime} - {entry.endTime} ({duration} minutes)
                            </p>
                            {!entry.isOptimalVenue && isSpecializedVenue && (
                              <p className="text-amber-500 text-xs">
                                Note: Venue type doesn't match subject requirements
                              </p>
                            )}
                          </div>
                        </TooltipContent>
                      </Tooltip>
                    )
                  })}
                </TooltipProvider>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
