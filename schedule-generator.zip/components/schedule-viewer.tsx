"use client"

import { useState } from "react"
import type { ScheduleEntry, Class, Teacher, Venue } from "./schedule-generator"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { WeeklySchedule } from "./weekly-schedule"
import { Button } from "@/components/ui/button"
import { Download, FileDown, ImageIcon, Loader2 } from "lucide-react"

type ScheduleViewerProps = {
  schedule: ScheduleEntry[]
  classes: Class[]
  teachers: Teacher[]
  venues: Venue[]
}

export function ScheduleViewer({ schedule, classes, teachers, venues }: ScheduleViewerProps) {
  const [viewMode, setViewMode] = useState<"class" | "teacher" | "venue">("class")
  const [selectedClassId, setSelectedClassId] = useState<string>("")
  const [selectedTeacherId, setSelectedTeacherId] = useState<string>("")
  const [selectedVenueId, setSelectedVenueId] = useState<string>("")
  const [selectedForm, setSelectedForm] = useState<string>("all")
  const [exportFormat, setExportFormat] = useState<"pdf" | "png">("pdf")
  const [isExporting, setIsExporting] = useState(false)

  // Group classes by form
  const classesByForm: Record<number, Class[]> = {}
  classes.forEach((c) => {
    if (!classesByForm[c.form]) {
      classesByForm[c.form] = []
    }
    classesByForm[c.form].push(c)
  })

  // Filter schedule based on selection
  const filteredSchedule = schedule.filter((entry) => {
    if (viewMode === "class") {
      if (selectedClassId) {
        return entry.classId === selectedClassId
      } else if (selectedForm !== "all") {
        return entry.form === Number.parseInt(selectedForm)
      }
      return true
    } else if (viewMode === "teacher") {
      return selectedTeacherId ? entry.teacherId === selectedTeacherId : true
    } else if (viewMode === "venue") {
      return selectedVenueId ? entry.venueId === selectedVenueId : true
    }
    return true
  })

  // Get current view title for export
  const getExportTitle = () => {
    if (viewMode === "class") {
      if (selectedClassId) {
        const classItem = classes.find((c) => c.id === selectedClassId)
        return `Schedule for ${classItem?.name || "Selected Class"}`
      } else if (selectedForm !== "all") {
        return `Schedule for Form ${selectedForm}`
      }
      return "All Classes Schedule"
    } else if (viewMode === "teacher") {
      if (selectedTeacherId) {
        const teacher = teachers.find((t) => t.id === selectedTeacherId)
        return `Schedule for ${teacher?.name || "Selected Teacher"}`
      }
      return "All Teachers Schedule"
    } else if (viewMode === "venue") {
      if (selectedVenueId) {
        const venue = venues.find((v) => v.id === selectedVenueId)
        return `Schedule for ${venue?.name || "Selected Venue"}`
      }
      return "All Venues Schedule"
    }
    return "School Schedule"
  }

  // Simple print export function
  const handlePrintExport = () => {
    setIsExporting(true)

    try {
      // Create a new window
      const printWindow = window.open("", "_blank")
      if (!printWindow) {
        alert("Please allow popups for this website")
        setIsExporting(false)
        return
      }

      // Generate colors for classes
      const classColors: Record<string, string> = {}
      filteredSchedule.forEach((entry) => {
        if (!classColors[entry.classId]) {
          const hue = Math.floor(Math.random() * 360)
          classColors[entry.classId] = `hsl(${hue}, 70%, 60%)`
        }
      })

      // Create HTML content
      let tableRows = ""
      const days = ["monday", "tuesday", "wednesday", "thursday", "friday"]
      const dayLabels = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
      const timeSlots = []

      // Create time slots
      for (let hour = 7; hour <= 14; hour++) {
        const hourStr = hour.toString().padStart(2, "0")
        if (hour === 7) {
          timeSlots.push(`${hourStr}:30`)
        } else {
          timeSlots.push(`${hourStr}:00`)
          if (hour < 14) timeSlots.push(`${hourStr}:30`)
        }
      }

      // Generate table rows
      timeSlots.forEach((timeSlot) => {
        // Special styling for recess time
        const isRecessTime = timeSlot === "10:30"

        tableRows += `<tr>
          <td style="border: 1px solid #ddd; padding: 8px; text-align: center; font-weight: 500; ${isRecessTime ? "background-color: #fff8e1;" : ""}">${timeSlot}</td>`

        days.forEach((day) => {
          // Check if this is recess time
          if (isRecessTime) {
            tableRows += `
              <td style="border: 1px solid #ddd; padding: 8px; background-color: #fff8e1; text-align: center; font-weight: 500; color: #b45309;">
                Recess Time
              </td>
            `
            return
          }

          // Find entries that start at this time slot for this day
          const entries = filteredSchedule.filter(
            (entry) => entry.day === day && entry.startTime === timeSlot && !entry.isRecess,
          )

          if (entries.length > 0) {
            const entry = entries[0] // Take the first entry if multiple exist
            const color = classColors[entry.classId]
            const isSpecializedVenue = entry.subjectCategory !== "normal"

            tableRows += `
              <td style="border: 1px solid #ddd; padding: 8px; border-left: 4px solid ${color}; background-color: ${color}15;">
                <div style="font-weight: bold; color: ${color}; margin-bottom: 4px;">
                  ${entry.className} - ${entry.subjectName}
                </div>
                <div style="font-size: 0.9em; margin-bottom: 2px;">
                  ${isSpecializedVenue ? `${entry.venueName} (Special)` : entry.venueName}
                </div>
                <div style="font-size: 0.9em; margin-bottom: 2px;">
                  ${entry.teacherName}
                </div>
                <div style="font-size: 0.8em; color: #666;">
                  ${entry.startTime} - ${entry.endTime}
                </div>
              </td>
            `
          } else {
            tableRows += `<td style="border: 1px solid #ddd; padding: 8px;"></td>`
          }
        })

        tableRows += `</tr>`
      })

      // Write the complete HTML to the new window
      printWindow.document.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>${getExportTitle()}</title>
            <style>
              body { 
                font-family: system-ui, -apple-system, sans-serif; 
                margin: 0; 
                padding: 20px; 
              }
              table { 
                width: 100%; 
                border-collapse: collapse; 
                margin-bottom: 20px;
              }
              th { 
                border: 1px solid #ddd; 
                padding: 8px; 
                background-color: #f8f9fa; 
                text-align: center;
              }
              @media print {
                body { padding: 0; }
                button { display: none; }
              }
            </style>
          </head>
          <body>
            <div style="text
              }
            </style>
          </head>
          <body>
            <div style="text-align: center; margin-bottom: 20px;">
              <h1 style="margin-bottom: 5px;">${getExportTitle()}</h1>
              <p style="color: #666; margin-top: 0;">Generated on: ${new Date().toLocaleDateString()}</p>
            </div>
            
            <div style="margin-bottom: 20px;">
              <button onclick="window.print();" style="padding: 8px 16px; background: #0070f3; color: white; border: none; border-radius: 4px; cursor: pointer;">
                Print / Save as PDF
              </button>
            </div>
            
            <table>
              <thead>
                <tr>
                  <th>Time</th>
                  ${dayLabels.map((day) => `<th>${day}</th>`).join("")}
                </tr>
              </thead>
              <tbody>
                ${tableRows}
              </tbody>
            </table>
          </body>
        </html>
      `)

      // Finish up
      printWindow.document.close()
    } catch (error) {
      console.error("Error during export:", error)
      alert(`Export failed: ${error instanceof Error ? error.message : "Unknown error"}`)
    } finally {
      setIsExporting(false)
    }
  }

  // Handle export based on selected format
  const handleExport = () => {
    handlePrintExport()
  }

  return (
    <Card>
      <CardContent className="p-4 space-y-4">
        <Tabs
          value={viewMode}
          onValueChange={(value) => {
            setViewMode(value as "class" | "teacher" | "venue")
            setSelectedClassId("")
            setSelectedTeacherId("")
            setSelectedVenueId("")
            setSelectedForm("all")
          }}
        >
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="class">By Class</TabsTrigger>
            <TabsTrigger value="teacher">By Teacher</TabsTrigger>
            <TabsTrigger value="venue">By Venue</TabsTrigger>
          </TabsList>

          <TabsContent value="class" className="space-y-4">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="form">Form</Label>
                <Select
                  value={selectedForm}
                  onValueChange={(value) => {
                    setSelectedForm(value)
                    setSelectedClassId("")
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select form" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Forms</SelectItem>
                    {Object.keys(classesByForm)
                      .sort()
                      .map((form) => (
                        <SelectItem key={form} value={form}>
                          Form {form}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="class">Class</Label>
                <Select value={selectedClassId} onValueChange={setSelectedClassId} disabled={selectedForm === "all"}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select class" />
                  </SelectTrigger>
                  <SelectContent>
                    {selectedForm === "all"
                      ? classes.map((c) => (
                          <SelectItem key={c.id} value={c.id}>
                            {c.name}
                          </SelectItem>
                        ))
                      : classesByForm[Number.parseInt(selectedForm)]?.map((c) => (
                          <SelectItem key={c.id} value={c.id}>
                            {c.name}
                          </SelectItem>
                        ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div id="schedule-container">
              {filteredSchedule.length > 0 ? (
                <WeeklySchedule schedule={filteredSchedule} />
              ) : (
                <div className="text-center p-10 border rounded-lg bg-muted/20">
                  <p className="text-muted-foreground">No schedule data available for the selected class.</p>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="teacher" className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="teacher">Teacher</Label>
              <Select value={selectedTeacherId} onValueChange={setSelectedTeacherId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select teacher" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Teachers</SelectItem>
                  {teachers.map((teacher) => (
                    <SelectItem key={teacher.id} value={teacher.id}>
                      {teacher.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div id="schedule-container">
              {filteredSchedule.length > 0 ? (
                <WeeklySchedule schedule={filteredSchedule} />
              ) : (
                <div className="text-center p-10 border rounded-lg bg-muted/20">
                  <p className="text-muted-foreground">No schedule data available for the selected teacher.</p>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="venue" className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="venue">Venue</Label>
              <Select value={selectedVenueId} onValueChange={setSelectedVenueId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select venue" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Venues</SelectItem>
                  {venues.map((venue) => (
                    <SelectItem key={venue.id} value={venue.id}>
                      {venue.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div id="schedule-container">
              {filteredSchedule.length > 0 ? (
                <WeeklySchedule schedule={filteredSchedule} />
              ) : (
                <div className="text-center p-10 border rounded-lg bg-muted/20">
                  <p className="text-muted-foreground">No schedule data available for the selected venue.</p>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>

        {filteredSchedule.length > 0 && (
          <div className="flex flex-col sm:flex-row gap-2 justify-end items-center pt-4 border-t">
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <Label htmlFor="export-format" className="whitespace-nowrap">
                Export Format:
              </Label>
              <Select value={exportFormat} onValueChange={(value) => setExportFormat(value as "pdf" | "png")}>
                <SelectTrigger id="export-format" className="w-[120px]">
                  <SelectValue placeholder="Select format" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pdf">
                    <div className="flex items-center gap-2">
                      <FileDown className="h-4 w-4" />
                      <span>PDF</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="png">
                    <div className="flex items-center gap-2">
                      <ImageIcon className="h-4 w-4" />
                      <span>PNG</span>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Button onClick={handleExport} disabled={isExporting} className="w-full sm:w-auto">
              {isExporting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Exporting...
                </>
              ) : (
                <>
                  <Download className="mr-2 h-4 w-4" />
                  Export {getExportTitle()}
                </>
              )}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
