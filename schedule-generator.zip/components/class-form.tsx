"use client"

import type React from "react"

import { useState } from "react"
import { v4 as uuidv4 } from "uuid"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { Class, Subject, Block } from "./schedule-generator"

// Define class categories
const CLASS_CATEGORIES = [
  { value: "normal", label: "Normal" },
  { value: "science", label: "Science Stream" },
  { value: "arts", label: "Arts Stream" },
  { value: "vocational", label: "Vocational" },
]

// Update the ClassForm component to include block selection
export function ClassForm({
  onSubmit,
  subjects,
  blocks,
}: {
  onSubmit: (classItem: Class) => void
  subjects: Subject[]
  blocks: Block[]
}) {
  // Single class form state
  const [name, setName] = useState("")
  const [form, setForm] = useState("1")
  const [homeRoom, setHomeRoom] = useState("")
  const [block, setBlock] = useState(blocks.length > 0 ? blocks[0].id : "")
  const [selectedSubjects, setSelectedSubjects] = useState<string[]>([])

  const handleSubjectToggle = (subjectId: string) => {
    setSelectedSubjects((prev) =>
      prev.includes(subjectId) ? prev.filter((s) => s !== subjectId) : [...prev, subjectId],
    )
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!name || !homeRoom || selectedSubjects.length === 0 || !block) {
      alert("Please fill in all required fields and select at least one subject")
      return
    }

    const classItem: Class = {
      id: uuidv4(),
      name,
      form: Number.parseInt(form),
      homeRoom,
      block,
      subjectIds: selectedSubjects,
    }

    onSubmit(classItem)

    // Reset form
    setName("")
    setForm("1")
    setHomeRoom("")
    setBlock(blocks.length > 0 ? blocks[0].id : "")
    setSelectedSubjects([])
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Add Class</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-4">
            <div className="space-y-2">
              <Label htmlFor="name">Class Name</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                placeholder="e.g., 1A, 2B, 3C"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="form">Form</Label>
              <Select value={form} onValueChange={setForm}>
                <SelectTrigger>
                  <SelectValue placeholder="Select form" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">Form 1</SelectItem>
                  <SelectItem value="2">Form 2</SelectItem>
                  <SelectItem value="3">Form 3</SelectItem>
                  <SelectItem value="4">Form 4</SelectItem>
                  <SelectItem value="5">Form 5</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="homeRoom">Home Room</Label>
              <Input
                id="homeRoom"
                value={homeRoom}
                onChange={(e) => setHomeRoom(e.target.value)}
                required
                placeholder="e.g., Room 101, Class 2B"
              />
              <p className="text-xs text-muted-foreground">The classroom where this class is normally located</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="block">Block/Building</Label>
              <Select value={block} onValueChange={setBlock}>
                <SelectTrigger>
                  <SelectValue placeholder="Select block" />
                </SelectTrigger>
                <SelectContent>
                  {blocks.map((blockItem) => (
                    <SelectItem key={blockItem.id} value={blockItem.id}>
                      {blockItem.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">The physical building where this class is located</p>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Subjects</Label>
            {subjects.length === 0 ? (
              <p className="text-sm text-muted-foreground">No subjects available. Please add subjects first.</p>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 border rounded-md p-3">
                {subjects.map((subject) => (
                  <div key={subject.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={`subject-${subject.id}`}
                      checked={selectedSubjects.includes(subject.id)}
                      onCheckedChange={() => handleSubjectToggle(subject.id)}
                    />
                    <Label htmlFor={`subject-${subject.id}`} className="text-sm">
                      {subject.name}
                    </Label>
                  </div>
                ))}
              </div>
            )}
          </div>

          <Button type="submit" className="w-full" disabled={subjects.length === 0}>
            Add Class
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}

// Update the ClassList component to show home rooms
function ClassList({
  classes,
  subjects,
  onDelete,
}: {
  classes: Class[]
  subjects: Subject[]
  onDelete: (id: string) => void
}) {
  if (classes.length === 0) {
    return <p className="text-muted-foreground text-center py-4">No classes added yet.</p>
  }

  // Group classes by form
  const classesByForm: Record<number, Class[]> = {}
  classes.forEach((c) => {
    if (!classesByForm[c.form]) {
      classesByForm[c.form] = []
    }
    classesByForm[c.form].push(c)
  })

  // Get subject names for a class
  const getSubjectNames = (subjectIds: string[]): string => {
    return subjectIds
      .map((id) => subjects.find((s) => s.id === id)?.name || "")
      .filter(Boolean)
      .join(", ")
  }

  return (
    <div className="space-y-6">
      {Object.entries(classesByForm)
        .sort(([formA], [formB]) => Number.parseInt(formA) - Number.parseInt(formB))
        .map(([form, formClasses]) => (
          <div key={form} className="space-y-2">
            <h3 className="text-lg font-medium">Form {form}</h3>
            <div className="border rounded-lg divide-y">
              {formClasses.map((classItem) => (
                <div key={classItem.id} className="p-4 flex justify-between items-center">
                  <div>
                    <h3 className="font-medium">{classItem.name}</h3>
                    <p className="text-sm text-muted-foreground">
                      Home Room: {classItem.homeRoom} | Subjects: {getSubjectNames(classItem.subjectIds)}
                    </p>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => onDelete(classItem.id)}>
                    Remove
                  </Button>
                </div>
              ))}
            </div>
          </div>
        ))}
    </div>
  )
}
