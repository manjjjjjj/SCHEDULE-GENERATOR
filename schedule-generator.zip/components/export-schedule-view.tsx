"use client"

import type { ScheduleEntry } from "./schedule-generator"

type ExportScheduleViewProps = {
  schedule: ScheduleEntry[]
  title: string
  date: string
}

export function ExportScheduleView({ schedule, title, date }: ExportScheduleViewProps) {
  const days = ["monday", "tuesday", "wednesday", "thursday", "friday"]
  const dayLabels = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]

  // Create time slots from 7:30 to 14:00 (7:30am to 2pm)
  const timeSlots = []
  for (let hour = 7; hour <= 14; hour++) {
    const hourStr = hour.toString().padStart(2, "0")
    if (hour === 7) {
      timeSlots.push(`${hourStr}:30`)
    } else {
      timeSlots.push(`${hourStr}:00`)
      if (hour < 14) timeSlots.push(`${hourStr}:30`)
    }
  }

  // Create a simple 2D array representation of the schedule
  const scheduleMatrix: (ScheduleEntry | null)[][] = []

  // Initialize empty matrix
  for (let i = 0; i < timeSlots.length; i++) {
    scheduleMatrix[i] = []
    for (let j = 0; j < days.length; j++) {
      scheduleMatrix[i][j] = null
    }
  }

  // Fill matrix with schedule entries
  schedule.forEach((entry) => {
    const dayIndex = days.indexOf(entry.day)
    if (dayIndex === -1) return

    const startIndex = timeSlots.indexOf(entry.startTime)
    const endIndex = timeSlots.indexOf(entry.endTime)

    if (startIndex === -1) return

    // Place entry at the start time slot
    scheduleMatrix[startIndex][dayIndex] = entry

    // Mark subsequent slots as occupied (with a special value)
    for (let i = startIndex + 1; i < endIndex; i++) {
      scheduleMatrix[i][dayIndex] = { ...entry, id: `${entry.id}-continued` } as ScheduleEntry
    }
  })

  // Generate colors for each class
  const classColors: Record<string, string> = {}
  schedule.forEach((entry) => {
    if (!classColors[entry.classId]) {
      const hue = Math.floor(Math.random() * 360)
      classColors[entry.classId] = `hsl(${hue}, 70%, 60%)`
    }
  })

  if (schedule.length === 0) {
    return (
      <div className="text-center p-10 border rounded-lg bg-white">
        <p>No schedule data available.</p>
      </div>
    )
  }

  return (
    <div className="bg-white p-4">
      <div className="text-center mb-6">
        <h1 className="text-2xl font-bold">{title}</h1>
        <p className="text-sm text-gray-500">Generated on: {date}</p>
      </div>

      <table className="w-full border-collapse" style={{ borderSpacing: 0, borderCollapse: "collapse" }}>
        <thead>
          <tr>
            <th
              style={{
                border: "1px solid #ccc",
                padding: "8px",
                backgroundColor: "#f8f9fa",
                width: "10%",
                textAlign: "center",
              }}
            >
              Time
            </th>
            {dayLabels.map((day) => (
              <th
                key={day}
                style={{
                  border: "1px solid #ccc",
                  padding: "8px",
                  backgroundColor: "#f8f9fa",
                  width: "18%",
                  textAlign: "center",
                }}
              >
                {day}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {timeSlots.map((timeSlot, timeIndex) => (
            <tr key={timeSlot} style={{ backgroundColor: timeIndex % 2 === 0 ? "#ffffff" : "#f8f9fa" }}>
              <td style={{ border: "1px solid #ccc", padding: "8px", textAlign: "center", fontWeight: 500 }}>
                {timeSlot}
              </td>

              {days.map((day, dayIndex) => {
                const entry = scheduleMatrix[timeIndex][dayIndex]

                // Skip cells that are continuations of previous entries
                if (entry && entry.id.includes("-continued")) {
                  return null
                }

                if (entry) {
                  const color = classColors[entry.classId]
                  const startIndex = timeSlots.indexOf(entry.startTime)
                  const endIndex = timeSlots.indexOf(entry.endTime)
                  const rowSpan = endIndex - startIndex
                  const isSpecializedVenue = entry.subjectCategory !== "normal"

                  return (
                    <td
                      key={day}
                      rowSpan={rowSpan}
                      style={{
                        border: "1px solid #ccc",
                        padding: "8px",
                        backgroundColor: `${color}20`,
                        borderLeft: `4px solid ${color}`,
                        verticalAlign: "top",
                      }}
                    >
                      <div style={{ fontWeight: 600, color: color, marginBottom: "4px" }}>
                        {entry.className} - {entry.subjectName}
                      </div>
                      <div style={{ fontSize: "0.875rem", marginBottom: "2px" }}>
                        {isSpecializedVenue ? `${entry.venueName} (Special)` : entry.venueName}
                      </div>
                      <div style={{ fontSize: "0.875rem", color: "#666" }}>{entry.teacherName}</div>
                      <div style={{ fontSize: "0.75rem", color: "#888", marginTop: "4px" }}>
                        {entry.startTime} - {entry.endTime}
                      </div>
                    </td>
                  )
                }

                return <td key={day} style={{ border: "1px solid #ccc", padding: "8px" }}></td>
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
