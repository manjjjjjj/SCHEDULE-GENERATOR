"use client"

import type React from "react"

import { useState } from "react"
import { v4 as uuidv4 } from "uuid"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import type { Teacher, Subject } from "./schedule-generator"

const DAYS = [
  { id: "monday", label: "Monday" },
  { id: "tuesday", label: "Tuesday" },
  { id: "wednesday", label: "Wednesday" },
  { id: "thursday", label: "Thursday" },
  { id: "friday", label: "Friday" },
]

const TIME_SLOTS = [
  "07:30",
  "08:00",
  "08:30",
  "09:00",
  "09:30",
  "10:00",
  "10:30",
  "11:00",
  "11:30",
  "12:00",
  "12:30",
  "13:00",
  "13:30",
  "14:00",
]

export function TeacherForm({
  onSubmit,
  subjects,
}: {
  onSubmit: (teacher: Teacher) => void
  subjects: Subject[]
}) {
  const [name, setName] = useState("")
  const [selectedSubjects, setSelectedSubjects] = useState<string[]>([])
  const [availability, setAvailability] = useState<{ [key: string]: string[] }>({
    monday: [...TIME_SLOTS],
    tuesday: [...TIME_SLOTS],
    wednesday: [...TIME_SLOTS],
    thursday: [...TIME_SLOTS],
    friday: [...TIME_SLOTS],
  })

  const handleAvailabilityChange = (day: string, timeSlot: string, isChecked: boolean) => {
    setAvailability((prev) => {
      const updatedDay = isChecked
        ? [...(prev[day] || []), timeSlot]
        : (prev[day] || []).filter((slot) => slot !== timeSlot)

      return {
        ...prev,
        [day]: updatedDay,
      }
    })
  }

  const handleSubjectToggle = (subjectName: string) => {
    setSelectedSubjects((prev) =>
      prev.includes(subjectName) ? prev.filter((s) => s !== subjectName) : [...prev, subjectName],
    )
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!name || selectedSubjects.length === 0) {
      alert("Please fill in all required fields and select at least one subject")
      return
    }

    const teacher: Teacher = {
      id: uuidv4(),
      name,
      subjects: selectedSubjects,
      availability,
    }

    onSubmit(teacher)

    // Reset form
    setName("")
    setSelectedSubjects([])
    setAvailability({
      monday: [...TIME_SLOTS],
      tuesday: [...TIME_SLOTS],
      wednesday: [...TIME_SLOTS],
      thursday: [...TIME_SLOTS],
      friday: [...TIME_SLOTS],
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Add Teacher</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Teacher Name</Label>
            <Input id="name" value={name} onChange={(e) => setName(e.target.value)} required />
          </div>

          <div className="space-y-2">
            <Label>Subjects</Label>
            {subjects.length === 0 ? (
              <p className="text-sm text-muted-foreground">No subjects available. Please add subjects first.</p>
            ) : (
              <div className="grid grid-cols-2 gap-2 border rounded-md p-3">
                {subjects.map((subject) => (
                  <div key={subject.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={`subject-${subject.id}`}
                      checked={selectedSubjects.includes(subject.name)}
                      onCheckedChange={() => handleSubjectToggle(subject.name)}
                    />
                    <Label htmlFor={`subject-${subject.id}`} className="text-sm">
                      {subject.name}
                    </Label>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label>Availability</Label>
            <div className="border rounded-md p-4">
              <div className="grid grid-cols-6 gap-2 text-center text-sm font-medium border-b pb-2">
                <div>Time</div>
                {DAYS.map((day) => (
                  <div key={day.id}>{day.label}</div>
                ))}
              </div>

              <div className="mt-2 space-y-1">
                {TIME_SLOTS.map((timeSlot) => (
                  <div key={timeSlot} className="grid grid-cols-6 gap-2 items-center">
                    <div className="text-sm">{timeSlot}</div>
                    {DAYS.map((day) => (
                      <div key={`${day.id}-${timeSlot}`} className="flex justify-center">
                        <Checkbox
                          checked={availability[day.id]?.includes(timeSlot)}
                          onCheckedChange={(checked) => handleAvailabilityChange(day.id, timeSlot, checked === true)}
                        />
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            </div>
          </div>

          <Button type="submit" className="w-full" disabled={subjects.length === 0}>
            Add Teacher
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
