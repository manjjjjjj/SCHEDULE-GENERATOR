"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TeacherForm } from "./teacher-form"
import { ClassForm } from "./class-form"
import { VenueForm } from "./venue-form"
import { SubjectForm } from "./subject-form"
import { GenerateSchedule } from "./generate-schedule"
import { ScheduleViewer } from "./schedule-viewer"
import { Button } from "@/components/ui/button"
import { RefreshCw, BarChart3 } from "lucide-react"
import { AnalyticsTab } from "./analytics-tab"

export type Teacher = {
  id: string
  name: string
  subjects: string[]
  availability: {
    [key: string]: string[] // day: timeSlots
  }
}

export type Subject = {
  id: string
  name: string
  category: string // normal, lab, computer, etc.
  weeklyHours: number // total hours per week
  sessionsPerWeek?: number // optional, will be determined by the scheduler if not provided
}

// Update the Class type to include a block property
export type Class = {
  id: string
  name: string // e.g., "1A", "2B", etc.
  form: number // 1-5
  subjectIds: string[] // List of subjects for this class
  homeRoom: string // The classroom where this class is normally located
  block: string // Physical block/building where the class is located
}

// Add a new type for Block to track block distances
export type Block = {
  id: string
  name: string
  distanceMap: Record<string, number> // Maps to other blocks with relative distance values
}

export type Venue = {
  id: string
  name: string
  capacity: number
  category: string // normal, lab, computer, etc.
  availability: {
    [key: string]: string[] // day: timeSlots
  }
}

export type ScheduleEntry = {
  id: string
  classId: string
  className: string
  form: number
  subjectId: string
  subjectName: string
  teacherId: string
  teacherName: string
  venueId: string
  venueName: string
  day: string
  startTime: string
  endTime: string
  subjectCategory: string
  venueCategory: string
  isOptimalVenue: boolean
  isRecess?: boolean
}

// In the ScheduleGenerator component, add a new state for blocks
export function ScheduleGenerator() {
  const [teachers, setTeachers] = useState<Teacher[]>([])
  const [subjects, setSubjects] = useState<Subject[]>([])
  const [classes, setClasses] = useState<Class[]>([])
  const [venues, setVenues] = useState<Venue[]>([])
  const [schedule, setSchedule] = useState<ScheduleEntry[]>([])
  const [isGenerating, setIsGenerating] = useState(false)
  const [blocks, setBlocks] = useState<Block[]>([
    {
      id: "block-a",
      name: "Block A",
      distanceMap: { "block-a": 0, "block-b": 1, "block-c": 2, "block-d": 3 },
    },
    {
      id: "block-b",
      name: "Block B",
      distanceMap: { "block-a": 1, "block-b": 0, "block-c": 1, "block-d": 2 },
    },
    {
      id: "block-c",
      name: "Block C",
      distanceMap: { "block-a": 2, "block-b": 1, "block-c": 0, "block-d": 1 },
    },
    {
      id: "block-d",
      name: "Block D",
      distanceMap: { "block-a": 3, "block-b": 2, "block-c": 1, "block-d": 0 },
    },
  ])

  const addTeacher = (teacher: Teacher) => {
    setTeachers([...teachers, teacher])
  }

  const addSubject = (subject: Subject) => {
    setSubjects([...subjects, subject])
  }

  const addClass = (classItem: Class) => {
    setClasses([...classes, classItem])
  }

  const addVenue = (venue: Venue) => {
    setVenues([...venues, venue])
  }

  const removeTeacher = (id: string) => {
    setTeachers(teachers.filter((t) => t.id !== id))
  }

  const removeSubject = (id: string) => {
    setSubjects(subjects.filter((s) => s.id !== id))
    // Also remove this subject from any classes that have it
    setClasses(
      classes.map((c) => ({
        ...c,
        subjectIds: c.subjectIds.filter((sid) => sid !== id),
      })),
    )
  }

  const removeClass = (id: string) => {
    setClasses(classes.filter((c) => c.id !== id))
  }

  const removeVenue = (id: string) => {
    setVenues(venues.filter((v) => v.id !== id))
  }

  // Update the call to generateAutomaticSchedule in the ScheduleGenerator component
  const generateSchedule = () => {
    setIsGenerating(true)

    // Small delay to allow UI to update
    setTimeout(() => {
      const newSchedule = generateAutomaticSchedule(teachers, subjects, classes, venues, blocks)

      // Add recess entries for all classes
      const recessEntries = addRecessEntries(classes)

      setSchedule([...newSchedule, ...recessEntries])
      setIsGenerating(false)
    }, 500)
  }

  // Function to add recess entries for all classes
  const addRecessEntries = (classes: Class[]): ScheduleEntry[] => {
    const days = ["monday", "tuesday", "wednesday", "thursday", "friday"]
    const recessEntries: ScheduleEntry[] = []

    // For each class and each day, add a recess entry
    classes.forEach((classItem) => {
      days.forEach((day) => {
        recessEntries.push({
          id: `recess-${classItem.id}-${day}`,
          classId: classItem.id,
          className: classItem.name,
          form: classItem.form,
          subjectId: "recess",
          subjectName: "Recess",
          teacherId: "",
          teacherName: "",
          venueId: "",
          venueName: "Recess",
          day,
          startTime: "10:30",
          endTime: "11:00",
          subjectCategory: "recess",
          venueCategory: "recess",
          isOptimalVenue: true,
          isRecess: true,
        })
      })
    })

    return recessEntries
  }

  return (
    <div className="space-y-8">
      <Tabs defaultValue="teachers">
        <TabsList className="grid w-full grid-cols-7">
          <TabsTrigger value="teachers">Teachers</TabsTrigger>
          <TabsTrigger value="subjects">Subjects</TabsTrigger>
          <TabsTrigger value="classes">Classes</TabsTrigger>
          <TabsTrigger value="venues">Venues</TabsTrigger>
          <TabsTrigger value="generate">Generate</TabsTrigger>
          <TabsTrigger value="view">View Schedules</TabsTrigger>
          <TabsTrigger value="analytics">
            <BarChart3 className="h-4 w-4 mr-2" />
            Analytics
          </TabsTrigger>
        </TabsList>

        <TabsContent value="teachers" className="space-y-4">
          <TeacherForm onSubmit={addTeacher} subjects={subjects} />
          <TeacherList teachers={teachers} onDelete={removeTeacher} />
        </TabsContent>

        <TabsContent value="subjects" className="space-y-4">
          <SubjectForm onSubmit={addSubject} />
          <SubjectList subjects={subjects} onDelete={removeSubject} />
        </TabsContent>

        <TabsContent value="classes" className="space-y-4">
          <ClassForm onSubmit={addClass} subjects={subjects} blocks={blocks} />
          <ClassList classes={classes} subjects={subjects} blocks={blocks} onDelete={removeClass} />
        </TabsContent>

        <TabsContent value="venues" className="space-y-4">
          <VenueForm onSubmit={addVenue} />
          <VenueList venues={venues} onDelete={removeVenue} />
        </TabsContent>

        <TabsContent value="generate" className="space-y-4">
          <GenerateSchedule
            teachers={teachers}
            subjects={subjects}
            classes={classes}
            venues={venues}
            blocks={blocks}
            onGenerate={generateSchedule}
            isGenerating={isGenerating}
          />

          {schedule.length > 0 && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold">Generated Schedule</h2>
                <Button variant="outline" onClick={generateSchedule}>
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Regenerate
                </Button>
              </div>
            </div>
          )}
        </TabsContent>

        <TabsContent value="view" className="space-y-4">
          {schedule.length > 0 ? (
            <ScheduleViewer schedule={schedule} classes={classes} teachers={teachers} venues={venues} blocks={blocks} />
          ) : (
            <div className="text-center p-10 border rounded-lg bg-muted/20">
              <p className="text-muted-foreground">
                No schedule generated yet. Go to the "Generate" tab to create a schedule.
              </p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          {schedule.length > 0 ? (
            <AnalyticsTab
              schedule={schedule}
              classes={classes}
              teachers={teachers}
              venues={venues}
              subjects={subjects}
              blocks={blocks}
            />
          ) : (
            <div className="text-center p-10 border rounded-lg bg-muted/20">
              <p className="text-muted-foreground">
                No schedule generated yet. Go to the "Generate" tab to create a schedule.
              </p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}

// Helper components for displaying lists
function TeacherList({ teachers, onDelete }: { teachers: Teacher[]; onDelete: (id: string) => void }) {
  if (teachers.length === 0) {
    return <p className="text-muted-foreground text-center py-4">No teachers added yet.</p>
  }

  return (
    <div className="border rounded-lg divide-y">
      {teachers.map((teacher) => (
        <div key={teacher.id} className="p-4 flex justify-between items-center">
          <div>
            <h3 className="font-medium">{teacher.name}</h3>
            <p className="text-sm text-muted-foreground">Subjects: {teacher.subjects.join(", ")}</p>
          </div>
          <Button variant="ghost" size="sm" onClick={() => onDelete(teacher.id)}>
            Remove
          </Button>
        </div>
      ))}
    </div>
  )
}

function SubjectList({ subjects, onDelete }: { subjects: Subject[]; onDelete: (id: string) => void }) {
  if (subjects.length === 0) {
    return <p className="text-muted-foreground text-center py-4">No subjects added yet.</p>
  }

  // Helper function to get human-readable category labels
  const getCategoryLabel = (category: string): string => {
    const categories = {
      normal: "Normal Class",
      lab: "Laboratory",
      computer: "Computer Lab",
      workshop: "Workshop",
      studio: "Studio",
    }

    return categories[category as keyof typeof categories] || category
  }

  return (
    <div className="border rounded-lg divide-y">
      {subjects.map((subject) => (
        <div key={subject.id} className="p-4 flex justify-between items-center">
          <div>
            <h3 className="font-medium">{subject.name}</h3>
            <p className="text-sm text-muted-foreground">
              Type: {getCategoryLabel(subject.category)} | Hours: {subject.weeklyHours} per week
            </p>
          </div>
          <Button variant="ghost" size="sm" onClick={() => onDelete(subject.id)}>
            Remove
          </Button>
        </div>
      ))}
    </div>
  )
}

// Update the ClassList component to remove category references
function ClassList({
  classes,
  subjects,
  blocks,
  onDelete,
}: {
  classes: Class[]
  subjects: Subject[]
  blocks: Block[]
  onDelete: (id: string) => void
}) {
  if (classes.length === 0) {
    return <p className="text-muted-foreground text-center py-4">No classes added yet.</p>
  }

  // Group classes by form
  const classesByForm: Record<number, Class[]> = {}
  classes.forEach((c) => {
    if (!classesByForm[c.form]) {
      classesByForm[c.form] = []
    }
    classesByForm[c.form].push(c)
  })

  // Get subject names for a class
  const getSubjectNames = (subjectIds: string[]): string => {
    return subjectIds
      .map((id) => subjects.find((s) => s.id === id)?.name || "")
      .filter(Boolean)
      .join(", ")
  }

  // Get block name from block id
  const getBlockName = (blockId: string): string => {
    return blocks.find((b) => b.id === blockId)?.name || blockId
  }

  return (
    <div className="space-y-6">
      {Object.entries(classesByForm)
        .sort(([formA], [formB]) => Number.parseInt(formA) - Number.parseInt(formB))
        .map(([form, formClasses]) => (
          <div key={form} className="space-y-2">
            <h3 className="text-lg font-medium">Form {form}</h3>
            <div className="border rounded-lg divide-y">
              {formClasses.map((classItem) => (
                <div key={classItem.id} className="p-4 flex justify-between items-center">
                  <div>
                    <h3 className="font-medium">{classItem.name}</h3>
                    <p className="text-sm text-muted-foreground">
                      Home Room: {classItem.homeRoom} | Block: {getBlockName(classItem.block)}
                    </p>
                    <p className="text-sm text-muted-foreground">Subjects: {getSubjectNames(classItem.subjectIds)}</p>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => onDelete(classItem.id)}>
                    Remove
                  </Button>
                </div>
              ))}
            </div>
          </div>
        ))}
    </div>
  )
}

function VenueList({ venues, onDelete }: { venues: Venue[]; onDelete: (id: string) => void }) {
  if (venues.length === 0) {
    return <p className="text-muted-foreground text-center py-4">No venues added yet.</p>
  }

  // Helper function to get human-readable category labels
  const getCategoryLabel = (category: string): string => {
    const categories = {
      normal: "Regular Classroom",
      lab: "Science Laboratory",
      computer: "Computer Laboratory",
      workshop: "Workshop Room",
      studio: "Studio",
    }

    return categories[category as keyof typeof categories] || category
  }

  return (
    <div className="border rounded-lg divide-y">
      {venues.map((venue) => (
        <div key={venue.id} className="p-4 flex justify-between items-center">
          <div>
            <h3 className="font-medium">{venue.name}</h3>
            <p className="text-sm text-muted-foreground">
              Type: {getCategoryLabel(venue.category)} | Capacity: {venue.capacity}
            </p>
          </div>
          <Button variant="ghost" size="sm" onClick={() => onDelete(venue.id)}>
            Remove
          </Button>
        </div>
      ))}
    </div>
  )
}

// Update the scheduling algorithm to consider blocks
function generateAutomaticSchedule(
  teachers: Teacher[],
  subjects: Subject[],
  classes: Class[],
  venues: Venue[],
  blocks: Block[],
): ScheduleEntry[] {
  const schedule: ScheduleEntry[] = []
  const days = ["monday", "tuesday", "wednesday", "thursday", "friday"]
  const timeSlots = generateTimeSlots("07:30", "14:00", 30) // 30-minute slots from 7:30am to 2pm

  // Track availability
  const teacherAvailability = { ...initializeAvailability(teachers) }
  const venueAvailability = { ...initializeAvailability(venues) }

  // Create a map of home room availability
  const homeRoomAvailability: Record<string, Record<string, string[]>> = {}
  classes.forEach((classItem) => {
    homeRoomAvailability[classItem.homeRoom] = {}
    days.forEach((day) => {
      homeRoomAvailability[classItem.homeRoom][day] = [...timeSlots]
    })
  })

  // Track teacher's classes per day to avoid teaching the same class multiple times in a day
  const teacherClassesPerDay: Record<string, Record<string, string[]>> = {}
  teachers.forEach((teacher) => {
    teacherClassesPerDay[teacher.id] = {}
    days.forEach((day) => {
      teacherClassesPerDay[teacher.id][day] = []
    })
  })

  // Track the last class taught by each teacher on each day
  const teacherLastClass: Record<
    string,
    Record<
      string,
      {
        classId: string
        endTimeIndex: number
        blockId: string // Track the block the teacher was last in
      }
    >
  > = {}

  teachers.forEach((teacher) => {
    teacherLastClass[teacher.id] = {}
    days.forEach((day) => {
      teacherLastClass[teacher.id][day] = {
        classId: "",
        endTimeIndex: -1,
        blockId: "",
      }
    })
  })

  // Add a new tracking object to limit subject sessions per day per class
  const classSubjectSessionsPerDay: Record<string, Record<string, Record<string, number>>> = {}

  // Initialize the tracking object
  classes.forEach((classItem) => {
    classSubjectSessionsPerDay[classItem.id] = {}
    days.forEach((day) => {
      classSubjectSessionsPerDay[classItem.id][day] = {}
      classItem.subjectIds.forEach((subjectId) => {
        classSubjectSessionsPerDay[classItem.id][day][subjectId] = 0
      })
    })
  })

  // Track teacher-class assignments to prevent a teacher from teaching the same class multiple times in a day
  const teacherClassAssignments: Record<string, Record<string, Record<string, boolean>>> = {}

  // Initialize the tracking object
  teachers.forEach((teacher) => {
    teacherClassAssignments[teacher.id] = {}
    days.forEach((day) => {
      teacherClassAssignments[teacher.id][day] = {}
      classes.forEach((classItem) => {
        teacherClassAssignments[teacher.id][day][classItem.id] = false
      })
    })
  })

  // Remove recess time (10:30-11:00) from all availabilities
  const recessStartIndex = timeSlots.indexOf("10:30")
  const recessEndIndex = timeSlots.indexOf("11:00")

  // Replace it with this updated code that only removes 10:30 (not 11:00):
  if (recessStartIndex !== -1 && recessEndIndex !== -1) {
    // Remove only the recess time slot (10:30) from teacher availability
    teachers.forEach((teacher) => {
      days.forEach((day) => {
        teacherAvailability[teacher.id][day] = teacherAvailability[teacher.id][day].filter((slot) => slot !== "10:30")
      })
    })

    // Remove only the recess time slot (10:30) from venue availability
    venues.forEach((venue) => {
      days.forEach((day) => {
        venueAvailability[venue.id][day] = venueAvailability[venue.id][day].filter((slot) => slot !== "10:30")
      })
    })

    // Remove only the recess time slot (10:30) from home room availability
    Object.keys(homeRoomAvailability).forEach((homeRoom) => {
      days.forEach((day) => {
        homeRoomAvailability[homeRoom][day] = homeRoomAvailability[homeRoom][day].filter((slot) => slot !== "10:30")
      })
    })
  }

  // Process each class
  classes.forEach((classItem) => {
    // For each subject in this class
    classItem.subjectIds.forEach((subjectId) => {
      const subject = subjects.find((s) => s.id === subjectId)
      if (!subject) return

      // Determine optimal number of sessions based on weekly hours
      const optimalSessionsPerWeek = determineOptimalSessions(subject.weeklyHours)
      const sessionsPerWeek = subject.sessionsPerWeek || optimalSessionsPerWeek

      let sessionsScheduled = 0
      let remainingHours = subject.weeklyHours

      // Try to schedule all required sessions for this subject
      while (sessionsScheduled < sessionsPerWeek && remainingHours > 0) {
        // Find suitable teachers for this subject
        const suitableTeachers = teachers.filter((teacher) => teacher.subjects.includes(subject.name))

        if (suitableTeachers.length === 0) continue

        // Try to find a slot
        let scheduled = false

        // Randomize days to distribute classes more evenly
        const prioritizedDays = ["monday", "tuesday", "wednesday", "thursday", "friday"]

        // We'll try days in this specific order to pack more classes earlier in the week
        const orderedDays = [...prioritizedDays] // No shuffling, maintain the Monday-to-Friday order

        for (const day of orderedDays) {
          if (scheduled) break

          // Try each possible starting time slot
          for (let startTimeIndex = 0; startTimeIndex < timeSlots.length; startTimeIndex++) {
            if (scheduled) break

            const startTime = timeSlots[startTimeIndex]

            // Skip if this is during recess time
            if (startTime === "10:30") continue

            // Calculate session duration based on remaining hours and max 2-hour constraint
            const maxSessionDuration = Math.min(remainingHours * 60, 60) // Max 1 hour (60 minutes)
            const sessionDuration = Math.min(maxSessionDuration, (subject.weeklyHours * 60) / sessionsPerWeek)

            // Calculate how many 30-minute slots we need
            const requiredSlotCount = Math.ceil(sessionDuration / 30)
            const endTimeIndex = startTimeIndex + requiredSlotCount

            // Skip if class would end after school hours
            if (endTimeIndex >= timeSlots.length) continue

            // Skip if the session would overlap with recess time
            if (
              (startTimeIndex < recessStartIndex && endTimeIndex > recessStartIndex) ||
              startTimeIndex === recessStartIndex
            )
              continue

            const endTime = timeSlots[endTimeIndex]

            // Get all consecutive slots needed for this session
            const requiredSlots = []
            for (let i = startTimeIndex; i < endTimeIndex; i++) {
              requiredSlots.push(timeSlots[i])
            }

            // Sort teachers to prioritize:
            // 1. Teachers who haven't taught this class today
            // 2. Teachers already in the same block
            // 3. Teachers who are in nearby blocks
            const sortedTeachers = [...suitableTeachers].sort((a, b) => {
              // First, prioritize teachers who haven't taught this class today
              const aHasTaughtClass = teacherClassAssignments[a.id]?.[day]?.[classItem.id] || false
              const bHasTaughtClass = teacherClassAssignments[b.id]?.[day]?.[classItem.id] || false

              if (aHasTaughtClass && !bHasTaughtClass) return 1
              if (!aHasTaughtClass && bHasTaughtClass) return -1

              // If both have or haven't taught this class, check block proximity
              const aLastClass = teacherLastClass[a.id][day]
              const bLastClass = teacherLastClass[b.id][day]

              // If teacher A is already in this block but teacher B is not
              if (aLastClass.blockId === classItem.block && bLastClass.blockId !== classItem.block) return -1
              if (bLastClass.blockId === classItem.block && aLastClass.blockId !== classItem.block) return 1

              // If both or neither have taught this class, prioritize by block proximity
              if (aLastClass.blockId && bLastClass.blockId) {
                const aDistance = getBlockDistance(aLastClass.blockId, classItem.block, blocks)
                const bDistance = getBlockDistance(bLastClass.blockId, classItem.block, blocks)
                return aDistance - bDistance
              }

              return 0
            })

            // Try each teacher
            for (const teacher of sortedTeachers) {
              if (scheduled) break

              // Check if teacher is available for all required slots
              const teacherIsAvailable = requiredSlots.every((slot) =>
                teacherAvailability[teacher.id]?.[day]?.includes(slot),
              )

              if (!teacherIsAvailable) continue

              // Check if this teacher has already taught this class today
              if (teacherClassAssignments[teacher.id]?.[day]?.[classItem.id]) {
                // Allow back-to-back sessions - check if the last class taught by this teacher was this class
                // and if the last session ended at the current start time (meaning they're consecutive)
                const lastClassInfo = teacherLastClass[teacher.id][day]
                const isBackToBack =
                  lastClassInfo.classId === classItem.id && timeSlots[lastClassInfo.endTimeIndex] === startTime

                if (!isBackToBack) {
                  // If not back-to-back, skip this teacher
                  continue
                }
              }

              // Check if this teacher needs a rest period
              const lastClassInfo = teacherLastClass[teacher.id][day]

              if (lastClassInfo.classId) {
                // If this is a different class than the last one taught
                if (lastClassInfo.classId !== classItem.id) {
                  // Calculate required rest time based on block distance
                  const blockDistance = lastClassInfo.blockId
                    ? getBlockDistance(lastClassInfo.blockId, classItem.block, blocks)
                    : 0

                  // Base rest time is 30 minutes (1 slot), add more for distant blocks
                  const requiredRestSlots = Math.max(1, blockDistance)

                  // Check if there's enough rest time
                  if (startTimeIndex - lastClassInfo.endTimeIndex < requiredRestSlots) {
                    // Not enough rest time between different classes
                    continue
                  }
                }
              }

              // Determine if we need a specialized venue or can use the home room
              const needsSpecializedVenue = subject.category !== "normal"

              if (needsSpecializedVenue) {
                // First try venues with matching category
                const matchingVenues = venues.filter((venue) => venue.category === subject.category)
                const otherVenues = venues.filter((venue) => venue.category !== subject.category)

                // Try matching venues first, then fall back to other venues if necessary
                const venueList = [...matchingVenues, ...otherVenues]

                for (const venue of venueList) {
                  // Check if venue is available for all required slots
                  const venueIsAvailable = requiredSlots.every((slot) =>
                    venueAvailability[venue.id]?.[day]?.includes(slot),
                  )

                  if (!venueIsAvailable) continue

                  // Check if we've already scheduled 2 sessions of this subject for this class today
                  if ((classSubjectSessionsPerDay[classItem.id]?.[day]?.[subjectId] || 0) >= 2) {
                    continue // Skip this slot if we already have 2 sessions of this subject today
                  }

                  // We found a suitable slot! Schedule the class
                  const scheduleEntry: ScheduleEntry = {
                    id: `${classItem.id}-${subjectId}-${sessionsScheduled}`,
                    classId: classItem.id,
                    className: classItem.name,
                    form: classItem.form,
                    subjectId: subject.id,
                    subjectName: subject.name,
                    teacherId: teacher.id,
                    teacherName: teacher.name,
                    venueId: venue.id,
                    venueName: venue.name,
                    day,
                    startTime,
                    endTime,
                    subjectCategory: subject.category,
                    venueCategory: venue.category,
                    isOptimalVenue: venue.category === subject.category,
                  }

                  schedule.push(scheduleEntry)

                  // Update the subject sessions counter for this class and day
                  classSubjectSessionsPerDay[classItem.id][day][subjectId] =
                    (classSubjectSessionsPerDay[classItem.id][day][subjectId] || 0) + 1

                  // Mark that this teacher has taught this class today
                  teacherClassAssignments[teacher.id][day][classItem.id] = true

                  // Update availability
                  requiredSlots.forEach((slot) => {
                    // Remove this slot from teacher availability
                    teacherAvailability[teacher.id][day] = teacherAvailability[teacher.id][day].filter(
                      (s) => s !== slot,
                    )

                    // Remove this slot from venue availability
                    venueAvailability[venue.id][day] = venueAvailability[venue.id][day].filter((s) => s !== slot)

                    // Remove this slot from home room availability
                    homeRoomAvailability[classItem.homeRoom][day] = homeRoomAvailability[classItem.homeRoom][
                      day
                    ].filter((s) => s !== slot)
                  })

                  // Record that this teacher taught this class today
                  teacherClassesPerDay[teacher.id][day].push(classItem.id)

                  // Update the last class taught by this teacher
                  teacherLastClass[teacher.id][day] = {
                    classId: classItem.id,
                    endTimeIndex: endTimeIndex,
                    blockId: classItem.block,
                  }

                  // Update remaining hours
                  remainingHours -= sessionDuration / 60

                  scheduled = true
                  sessionsScheduled++
                  break
                }
              } else {
                // Use the class's home room
                // Check if home room is available for all required slots
                const homeRoomIsAvailable = requiredSlots.every((slot) =>
                  homeRoomAvailability[classItem.homeRoom]?.[day]?.includes(slot),
                )

                if (!homeRoomIsAvailable) continue

                // Create a virtual venue for the home room
                const homeRoomVenue = {
                  id: `homeroom-${classItem.id}`,
                  name: classItem.homeRoom,
                  category: "normal",
                }

                // Check if we've already scheduled 2 sessions of this subject for this class today
                if ((classSubjectSessionsPerDay[classItem.id]?.[day]?.[subjectId] || 0) >= 2) {
                  continue // Skip this slot if we already have 2 sessions of this subject today
                }

                // We found a suitable slot! Schedule the class
                const scheduleEntry: ScheduleEntry = {
                  id: `${classItem.id}-${subjectId}-${sessionsScheduled}`,
                  classId: classItem.id,
                  className: classItem.name,
                  form: classItem.form,
                  subjectId: subject.id,
                  subjectName: subject.name,
                  teacherId: teacher.id,
                  teacherName: teacher.name,
                  venueId: homeRoomVenue.id,
                  venueName: homeRoomVenue.name,
                  day,
                  startTime,
                  endTime,
                  subjectCategory: subject.category,
                  venueCategory: "normal",
                  isOptimalVenue: true,
                }

                schedule.push(scheduleEntry)

                // Update the subject sessions counter for this class and day
                classSubjectSessionsPerDay[classItem.id][day][subjectId] =
                  (classSubjectSessionsPerDay[classItem.id][day][subjectId] || 0) + 1

                // Mark that this teacher has taught this class today
                teacherClassAssignments[teacher.id][day][classItem.id] = true

                // Update availability
                requiredSlots.forEach((slot) => {
                  // Remove this slot from teacher availability
                  teacherAvailability[teacher.id][day] = teacherAvailability[teacher.id][day].filter((s) => s !== slot)

                  // Remove this slot from home room availability
                  homeRoomAvailability[classItem.homeRoom][day] = homeRoomAvailability[classItem.homeRoom][day].filter(
                    (s) => s !== slot,
                  )
                })

                // Record that this teacher taught this class today
                teacherClassesPerDay[teacher.id][day].push(classItem.id)

                // Update the last class taught by this teacher
                teacherLastClass[teacher.id][day] = {
                  classId: classItem.id,
                  endTimeIndex: endTimeIndex,
                  blockId: classItem.block,
                }

                // Update remaining hours
                remainingHours -= sessionDuration / 60

                scheduled = true
                sessionsScheduled++
              }
            }
          }
        }

        // If we couldn't schedule this session, break to avoid infinite loop
        if (!scheduled) break
      }
    })
  })

  return schedule
}

// Helper function to get the distance between two blocks
function getBlockDistance(blockId1: string, blockId2: string, blocks: Block[]): number {
  if (blockId1 === blockId2) return 0

  const block1 = blocks.find((b) => b.id === blockId1)
  if (!block1) return 3 // Default to a high distance if block not found

  return block1.distanceMap[blockId2] || 3
}

// Helper function to initialize availability tracking
function initializeAvailability(items: (Teacher | Venue)[]) {
  const availability: { [key: string]: { [key: string]: string[] } } = {}

  items.forEach((item) => {
    availability[item.id] = { ...item.availability }
  })

  return availability
}

// Helper function to generate time slots
function generateTimeSlots(startTime: string, endTime: string, intervalMinutes: number): string[] {
  const slots: string[] = []
  let current = new Date(`2000-01-01T${startTime}:00`)
  const end = new Date(`2000-01-01T${endTime}:00`)

  while (current < end) {
    slots.push(current.toTimeString().substring(0, 5))
    current = new Date(current.getTime() + intervalMinutes * 60000)
  }

  return slots
}

// Helper function to determine optimal number of sessions based on weekly hours
function determineOptimalSessions(weeklyHours: number): number {
  // For 1 hour, use 1 session
  if (weeklyHours === 1) return 1

  // For 2 hours, use 2 sessions (two 1-hour sessions)
  if (weeklyHours === 2) return 2

  // For 3 hours, use 3 sessions (three 1-hour sessions)
  if (weeklyHours === 3) return 3

  // For 4 hours, use 4 sessions (four 1-hour sessions)
  if (weeklyHours === 4) return 4

  // For 5 hours, use 5 sessions (five 1-hour sessions)
  if (weeklyHours === 5) return 5

  // For 6 hours, use 6 sessions (six 1-hour sessions)
  if (weeklyHours === 6) return 6

  // Default: one session per hour
  return Math.ceil(weeklyHours)
}
