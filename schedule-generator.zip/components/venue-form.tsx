"use client"

import type React from "react"

import { useState } from "react"
import { v4 as uuidv4 } from "uuid"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { Venue } from "./schedule-generator"

const DAYS = [
  { id: "monday", label: "Monday" },
  { id: "tuesday", label: "Tuesday" },
  { id: "wednesday", label: "Wednesday" },
  { id: "thursday", label: "Thursday" },
  { id: "friday", label: "Friday" },
]

const TIME_SLOTS = [
  "07:30",
  "08:00",
  "08:30",
  "09:00",
  "09:30",
  "10:00",
  "10:30",
  "11:00",
  "11:30",
  "12:00",
  "12:30",
  "13:00",
  "13:30",
  "14:00",
]

// Define venue categories
const VENUE_CATEGORIES = [
  { value: "normal", label: "Regular Classroom" },
  { value: "lab", label: "Science Laboratory" },
  { value: "computer", label: "Computer Laboratory" },
  { value: "workshop", label: "Workshop Room" },
  { value: "studio", label: "Studio" },
]

// Update the venue form title and description to clarify its purpose
export function VenueForm({ onSubmit }: { onSubmit: (venue: Venue) => void }) {
  const [name, setName] = useState("")
  const [capacity, setCapacity] = useState("30")
  const [category, setCategory] = useState("normal")
  const [availability, setAvailability] = useState<{ [key: string]: string[] }>({
    monday: [...TIME_SLOTS],
    tuesday: [...TIME_SLOTS],
    wednesday: [...TIME_SLOTS],
    thursday: [...TIME_SLOTS],
    friday: [...TIME_SLOTS],
  })

  const handleAvailabilityChange = (day: string, timeSlot: string, isChecked: boolean) => {
    setAvailability((prev) => {
      const updatedDay = isChecked
        ? [...(prev[day] || []), timeSlot]
        : (prev[day] || []).filter((slot) => slot !== timeSlot)

      return {
        ...prev,
        [day]: updatedDay,
      }
    })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!name) {
      alert("Please fill in all required fields")
      return
    }

    const venue: Venue = {
      id: uuidv4(),
      name,
      capacity: Number.parseInt(capacity),
      category,
      availability,
    }

    onSubmit(venue)

    // Reset form
    setName("")
    setCapacity("30")
    setCategory("normal")
    setAvailability({
      monday: [...TIME_SLOTS],
      tuesday: [...TIME_SLOTS],
      wednesday: [...TIME_SLOTS],
      thursday: [...TIME_SLOTS],
      friday: [...TIME_SLOTS],
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Add Specialized Venue</CardTitle>
        <p className="text-sm text-muted-foreground">
          Add specialized venues like labs, computer rooms, etc. Regular classes will use their home rooms.
        </p>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div className="space-y-2">
              <Label htmlFor="name">Venue Name</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                placeholder="e.g., Science Lab 1, Computer Lab"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="capacity">Capacity</Label>
              <Input
                id="capacity"
                type="number"
                min="1"
                value={capacity}
                onChange={(e) => setCapacity(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="category">Venue Type</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger>
                  <SelectValue placeholder="Select venue type" />
                </SelectTrigger>
                <SelectContent>
                  {VENUE_CATEGORIES.map((category) => (
                    <SelectItem key={category.value} value={category.value}>
                      {category.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Availability</Label>
            <div className="border rounded-md p-4">
              <div className="grid grid-cols-6 gap-2 text-center text-sm font-medium border-b pb-2">
                <div>Time</div>
                {DAYS.map((day) => (
                  <div key={day.id}>{day.label}</div>
                ))}
              </div>

              <div className="mt-2 space-y-1">
                {TIME_SLOTS.map((timeSlot) => (
                  <div key={timeSlot} className="grid grid-cols-6 gap-2 items-center">
                    <div className="text-sm">{timeSlot}</div>
                    {DAYS.map((day) => (
                      <div key={`${day.id}-${timeSlot}`} className="flex justify-center">
                        <Checkbox
                          checked={availability[day.id]?.includes(timeSlot)}
                          onCheckedChange={(checked) => handleAvailabilityChange(day.id, timeSlot, checked === true)}
                        />
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            </div>
          </div>

          <Button type="submit" className="w-full">
            Add Specialized Venue
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
