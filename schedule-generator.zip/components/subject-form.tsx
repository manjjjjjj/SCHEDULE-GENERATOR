"use client"

import type React from "react"

import { useState } from "react"
import { v4 as uuidv4 } from "uuid"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { Subject } from "./schedule-generator"

// Define subject categories
const SUBJECT_CATEGORIES = [
  { value: "normal", label: "Normal Class" },
  { value: "lab", label: "Laboratory" },
  { value: "computer", label: "Computer Lab" },
  { value: "workshop", label: "Workshop" },
  { value: "studio", label: "Studio" },
]

export function SubjectForm({ onSubmit }: { onSubmit: (subject: Subject) => void }) {
  const [name, setName] = useState("")
  const [category, setCategory] = useState("normal")
  const [weeklyHours, setWeeklyHours] = useState("3")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!name) {
      alert("Please fill in all required fields")
      return
    }

    const subject: Subject = {
      id: uuidv4(),
      name,
      category,
      weeklyHours: Number.parseInt(weeklyHours),
    }

    onSubmit(subject)

    // Reset form
    setName("")
    setCategory("normal")
    setWeeklyHours("3")
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Add Subject</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Subject Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              placeholder="e.g., Mathematics, Physics, English"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="category">Subject Type</Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger>
                <SelectValue placeholder="Select subject type" />
              </SelectTrigger>
              <SelectContent>
                {SUBJECT_CATEGORIES.map((category) => (
                  <SelectItem key={category.value} value={category.value}>
                    {category.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground mt-1">
              Select "Laboratory" for science experiments, "Computer Lab" for programming classes, etc.
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="weeklyHours">Weekly Hours</Label>
            <Select value={weeklyHours} onValueChange={setWeeklyHours}>
              <SelectTrigger>
                <SelectValue placeholder="Select hours" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">1 hour</SelectItem>
                <SelectItem value="2">2 hours</SelectItem>
                <SelectItem value="3">3 hours</SelectItem>
                <SelectItem value="4">4 hours</SelectItem>
                <SelectItem value="5">5 hours</SelectItem>
                <SelectItem value="6">6 hours</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground mt-1">
              The scheduler will automatically determine the optimal number of sessions per week
            </p>
          </div>

          <Button type="submit" className="w-full">
            Add Subject
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
