"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import type { Teacher, Subject, Class, Venue, Block } from "./schedule-generator"
import { AlertCircle, CheckCircle2, Info } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

type GenerateScheduleProps = {
  teachers: Teacher[]
  subjects: Subject[]
  classes: Class[]
  venues: Venue[]
  blocks: Block[]
  onGenerate: () => void
  isGenerating: boolean
}

// Update the GenerateSchedule component to check for specialized venues
export function GenerateSchedule({
  teachers,
  subjects,
  classes,
  venues,
  blocks,
  onGenerate,
  isGenerating,
}: GenerateScheduleProps) {
  const canGenerate = teachers.length > 0 && subjects.length > 0 && classes.length > 0

  const getSubjectCoverage = () => {
    // Get all subject names from the subjects list
    const subjectNames = subjects.map((s) => s.name)

    // Get all subject names that teachers can teach
    const teacherSubjects = new Set(teachers.flatMap((t) => t.subjects))

    // Find subjects that don't have teachers assigned
    const uncoveredSubjects = subjectNames.filter((subject) => !teacherSubjects.has(subject))

    return {
      covered: uncoveredSubjects.length === 0,
      uncoveredSubjects,
    }
  }

  const getVenueCoverage = () => {
    // Get all specialized subject categories (non-normal)
    const specializedSubjectCategories = new Set(subjects.filter((s) => s.category !== "normal").map((s) => s.category))

    // Get all specialized venue categories
    const specializedVenueCategories = new Set(venues.filter((v) => v.category !== "normal").map((v) => v.category))

    // Find specialized subject categories that don't have matching venues
    const missingVenueTypes = [...specializedSubjectCategories].filter(
      (category) => !specializedVenueCategories.has(category),
    )

    return {
      covered: missingVenueTypes.length === 0,
      missingVenueTypes,
    }
  }

  const getClassSubjectCoverage = () => {
    // Check if all classes have subjects assigned
    const classesWithoutSubjects = classes.filter((c) => c.subjectIds.length === 0)

    // Check if all classes have valid subjects (that exist in the subjects list)
    const allSubjectIds = new Set(subjects.map((s) => s.id))
    const classesWithInvalidSubjects = classes.filter((c) => c.subjectIds.some((sid) => !allSubjectIds.has(sid)))

    // Check if all classes have home rooms
    const classesWithoutHomeRooms = classes.filter((c) => !c.homeRoom)

    return {
      covered:
        classesWithoutSubjects.length === 0 &&
        classesWithInvalidSubjects.length === 0 &&
        classesWithoutHomeRooms.length === 0,
      classesWithoutSubjects,
      classesWithInvalidSubjects,
      classesWithoutHomeRooms,
    }
  }

  const subjectCoverage = getSubjectCoverage()
  const venueCoverage = getVenueCoverage()
  const classSubjectCoverage = getClassSubjectCoverage()

  return (
    <Card>
      <CardHeader className="bg-primary/5">
        <CardTitle className="text-primary">Generate Schedule</CardTitle>
        <CardDescription>
          Add teachers, subjects, classes, and specialized venues before generating a schedule
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4 pt-6">
        <div className="grid grid-cols-1 gap-4 md:grid-cols-4">
          <StatusCard
            title="Teachers"
            count={teachers.length}
            status={teachers.length > 0 ? "success" : "warning"}
            message={teachers.length > 0 ? "Ready" : "Add at least one teacher"}
          />
          <StatusCard
            title="Subjects"
            count={subjects.length}
            status={subjects.length > 0 ? "success" : "warning"}
            message={subjects.length > 0 ? "Ready" : "Add at least one subject"}
          />
          <StatusCard
            title="Classes"
            count={classes.length}
            status={classes.length > 0 ? "success" : "warning"}
            message={classes.length > 0 ? "Ready" : "Add at least one class"}
          />
          <StatusCard
            title="Specialized Venues"
            count={venues.length}
            status={venues.length > 0 || !subjects.some((s) => s.category !== "normal") ? "success" : "warning"}
            message={
              venues.length > 0 || !subjects.some((s) => s.category !== "normal") ? "Ready" : "Add specialized venues"
            }
          />
        </div>

        <div className="bg-primary/5 p-4 rounded-lg border">
          <h3 className="font-medium mb-2 text-primary">Teacher-Friendly Scheduling</h3>
          <ul className="space-y-1 text-sm">
            <li className="flex items-start">
              <span className="mr-2">•</span>
              <span>Teachers will have at least 30 minutes between different classes to rest and travel</span>
            </li>
            <li className="flex items-start">
              <span className="mr-2">•</span>
              <span>Teaching sessions are limited to a maximum of 1 hour to prevent fatigue</span>
            </li>
            <li className="flex items-start">
              <span className="mr-2">•</span>
              <span>All sessions are limited to 1 hour maximum for optimal learning and teaching</span>
            </li>
            <li className="flex items-start">
              <span className="mr-2">•</span>
              <span>Teachers can teach the same class twice in a day if sessions are back-to-back</span>
            </li>
            <li className="flex items-start">
              <span className="mr-2">•</span>
              <span>Classes stay in their home rooms except for subjects requiring specialized venues</span>
            </li>
            <li className="flex items-start">
              <span className="mr-2">•</span>
              <span>Recess time is reserved from 10:30 to 11:00 every day</span>
            </li>
            <li className="flex items-start">
              <span className="mr-2">•</span>
              <span>Weekly hours are automatically distributed into 1-hour teaching sessions</span>
            </li>
            <li className="flex items-start">
              <span className="mr-2">•</span>
              <span>
                Teachers will complete their lectures in one block before moving to other blocks to minimize travel time
              </span>
            </li>
            <li className="flex items-start">
              <span className="mr-2">•</span>
              <span>Schedule is packed more heavily on Monday, gradually decreasing to a lighter Friday</span>
            </li>
            <li className="flex items-start">
              <span className="mr-2">•</span>
              <span>No more than 2 sessions of the same subject will be scheduled for a class on any given day</span>
            </li>
          </ul>
        </div>

        {!subjectCoverage.covered && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Subject coverage issue</AlertTitle>
            <AlertDescription>
              The following subjects don't have teachers assigned: {subjectCoverage.uncoveredSubjects.join(", ")}
            </AlertDescription>
          </Alert>
        )}

        {!venueCoverage.covered && (
          <Alert variant="warning">
            <Info className="h-4 w-4" />
            <AlertTitle>Specialized venue issue</AlertTitle>
            <AlertDescription>
              You have subjects that require these specialized venue types, but no matching venues:{" "}
              {venueCoverage.missingVenueTypes.map((type) => getCategoryLabel(type)).join(", ")}
            </AlertDescription>
          </Alert>
        )}

        {!classSubjectCoverage.covered && (
          <Alert variant="warning">
            <Info className="h-4 w-4" />
            <AlertTitle>Class configuration issue</AlertTitle>
            <AlertDescription>
              {classSubjectCoverage.classesWithoutSubjects.length > 0 && (
                <p>
                  The following classes have no subjects assigned:{" "}
                  {classSubjectCoverage.classesWithoutSubjects.map((c) => c.name).join(", ")}
                </p>
              )}
              {classSubjectCoverage.classesWithInvalidSubjects.length > 0 && (
                <p>
                  The following classes have invalid subjects:{" "}
                  {classSubjectCoverage.classesWithInvalidSubjects.map((c) => c.name).join(", ")}
                </p>
              )}
              {classSubjectCoverage.classesWithoutHomeRooms.length > 0 && (
                <p>
                  The following classes don't have home rooms assigned:{" "}
                  {classSubjectCoverage.classesWithoutHomeRooms.map((c) => c.name).join(", ")}
                </p>
              )}
            </AlertDescription>
          </Alert>
        )}

        <Button
          onClick={onGenerate}
          disabled={!canGenerate || isGenerating}
          className="w-full bg-primary hover:bg-primary/90"
        >
          {isGenerating ? "Generating..." : "Generate Schedule"}
        </Button>
      </CardContent>
    </Card>
  )
}

type StatusCardProps = {
  title: string
  count: number
  status: "success" | "warning" | "error"
  message: string
}

function StatusCard({ title, count, status, message }: StatusCardProps) {
  return (
    <div className="flex flex-col items-center justify-center p-4 border rounded-lg bg-white">
      <h3 className="font-medium">{title}</h3>
      <div className="text-3xl font-bold my-2 text-primary">{count}</div>
      <div className="flex items-center text-sm">
        {status === "success" ? (
          <CheckCircle2 className="h-4 w-4 text-green-500 mr-1" />
        ) : (
          <AlertCircle className="h-4 w-4 text-amber-500 mr-1" />
        )}
        <span className={status === "success" ? "text-green-500" : "text-amber-500"}>{message}</span>
      </div>
    </div>
  )
}

// Helper function to get human-readable category labels
function getCategoryLabel(category: string): string {
  const categories = {
    normal: "Normal Class/Regular Classroom",
    lab: "Laboratory",
    computer: "Computer Lab",
    workshop: "Workshop",
    studio: "Studio",
  }

  return categories[category as keyof typeof categories] || category
}
