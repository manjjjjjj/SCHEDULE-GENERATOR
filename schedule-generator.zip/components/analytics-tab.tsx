"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Clock, Users, BookOpen, Building, BarChart3 } from "lucide-react"
import type { ScheduleEntry, Teacher, Subject, Class, Venue, Block } from "./schedule-generator"

type AnalyticsTabProps = {
  schedule: ScheduleEntry[]
  teachers: Teacher[]
  subjects: Subject[]
  classes: Class[]
  venues: Venue[]
  blocks: Block[]
}

export function AnalyticsTab({ schedule, teachers, subjects, classes, venues, blocks }: AnalyticsTabProps) {
  const [analyticsView, setAnalyticsView] = useState<"teachers" | "classes" | "venues" | "subjects">("teachers")

  if (schedule.length === 0) {
    return (
      <div className="text-center p-10 border rounded-lg bg-muted/20">
        <p className="text-muted-foreground">
          No schedule data available. Generate a schedule first to view analytics.
        </p>
      </div>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Schedule Analytics</CardTitle>
        <CardDescription>View detailed statistics and insights about your schedule</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Tabs
          value={analyticsView}
          onValueChange={(value) => setAnalyticsView(value as "teachers" | "classes" | "venues" | "subjects")}
        >
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="teachers">
              <Users className="h-4 w-4 mr-2" />
              Teachers
            </TabsTrigger>
            <TabsTrigger value="classes">
              <Users className="h-4 w-4 mr-2" />
              Classes
            </TabsTrigger>
            <TabsTrigger value="subjects">
              <BookOpen className="h-4 w-4 mr-2" />
              Subjects
            </TabsTrigger>
            <TabsTrigger value="venues">
              <Building className="h-4 w-4 mr-2" />
              Venues
            </TabsTrigger>
          </TabsList>

          <TabsContent value="teachers" className="space-y-4">
            <TeacherAnalytics
              schedule={schedule}
              teachers={teachers}
              subjects={subjects}
              blocks={blocks}
              classes={classes}
            />
          </TabsContent>

          <TabsContent value="classes" className="space-y-4">
            <ClassAnalytics schedule={schedule} classes={classes} subjects={subjects} />
          </TabsContent>

          <TabsContent value="subjects" className="space-y-4">
            <SubjectAnalytics schedule={schedule} subjects={subjects} />
          </TabsContent>

          <TabsContent value="venues" className="space-y-4">
            <VenueAnalytics schedule={schedule} venues={venues} />
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

// Add block movement analysis to the TeacherAnalytics component

function TeacherAnalytics({
  schedule,
  teachers,
  subjects,
  blocks,
  classes,
}: {
  schedule: ScheduleEntry[]
  teachers: Teacher[]
  subjects: Subject[]
  blocks: Block[]
  classes: Class[]
}) {
  const [selectedTeacherId, setSelectedTeacherId] = useState<string>(teachers.length > 0 ? teachers[0].id : "")

  // Calculate teaching hours for each teacher
  const teacherHours: Record<
    string,
    {
      totalMinutes: number
      byDay: Record<string, number>
      bySubject: Record<string, number>
      blockMovements: Record<string, number> // Track movements between blocks
      byBlock: Record<string, number> // Track time spent in each block
    }
  > = {}

  teachers.forEach((teacher) => {
    teacherHours[teacher.id] = {
      totalMinutes: 0,
      byDay: { monday: 0, tuesday: 0, wednesday: 0, thursday: 0, friday: 0 },
      bySubject: {},
      blockMovements: { monday: 0, tuesday: 0, wednesday: 0, thursday: 0, friday: 0 },
      byBlock: {},
    }
  })

  // Process schedule to calculate teaching hours and block movements
  const teacherBlockSequence: Record<string, Record<string, string[]>> = {}

  // Initialize block sequence tracking
  teachers.forEach((teacher) => {
    teacherBlockSequence[teacher.id] = {
      monday: [],
      tuesday: [],
      wednesday: [],
      thursday: [],
      friday: [],
    }
  })

  // Sort schedule entries by day and start time
  const sortedSchedule = [...schedule].sort((a, b) => {
    const dayOrder = { monday: 0, tuesday: 1, wednesday: 2, thursday: 3, friday: 4 }
    if (dayOrder[a.day] !== dayOrder[b.day]) {
      return dayOrder[a.day] - dayOrder[b.day]
    }
    return a.startTime.localeCompare(b.startTime)
  })

  // Process schedule to calculate teaching hours and track block movements
  sortedSchedule.forEach((entry) => {
    if (entry.isRecess) return // Skip recess entries

    const teacherId = entry.teacherId
    if (!teacherId || !teacherHours[teacherId]) return

    // Get class to determine block
    const classItem = classes.find((c) => c.id === entry.classId)
    if (!classItem) return

    const blockId = classItem.block
    const blockName = blocks.find((b) => b.id === blockId)?.name || blockId

    // Calculate duration in minutes
    const startTime = entry.startTime.split(":").map(Number)
    const endTime = entry.endTime.split(":").map(Number)
    const durationMinutes = endTime[0] * 60 + endTime[1] - (startTime[0] * 60 + startTime[1])

    // Add to total
    teacherHours[teacherId].totalMinutes += durationMinutes

    // Add to day total
    teacherHours[teacherId].byDay[entry.day] += durationMinutes

    // Add to subject total
    if (!teacherHours[teacherId].bySubject[entry.subjectName]) {
      teacherHours[teacherId].bySubject[entry.subjectName] = 0
    }
    teacherHours[teacherId].bySubject[entry.subjectName] += durationMinutes

    // Add to block total
    if (!teacherHours[teacherId].byBlock[blockName]) {
      teacherHours[teacherId].byBlock[blockName] = 0
    }
    teacherHours[teacherId].byBlock[blockName] += durationMinutes

    // Track block sequence
    teacherBlockSequence[teacherId][entry.day].push(blockId)
  })

  // Calculate block movements
  Object.entries(teacherBlockSequence).forEach(([teacherId, daySequences]) => {
    Object.entries(daySequences).forEach(([day, sequence]) => {
      if (sequence.length <= 1) return // No movements if only one or zero blocks

      let movements = 0
      for (let i = 1; i < sequence.length; i++) {
        if (sequence[i] !== sequence[i - 1]) {
          movements++
        }
      }

      teacherHours[teacherId].blockMovements[day as keyof (typeof teacherHours)[typeof teacherId]["blockMovements"]] =
        movements
    })
  })

  // Find the teacher with the most teaching hours for comparison
  const maxTeachingMinutes = Math.max(...Object.values(teacherHours).map((h) => h.totalMinutes))

  // Get selected teacher data
  const selectedTeacher = teachers.find((t) => t.id === selectedTeacherId)
  const selectedTeacherHours = selectedTeacherId ? teacherHours[selectedTeacherId] : null

  // Calculate average teaching minutes per day
  const avgMinutesPerDay = selectedTeacherHours
    ? Object.values(selectedTeacherHours.byDay).reduce((sum, mins) => sum + mins, 0) / 5
    : 0

  // Calculate total block movements
  const totalBlockMovements = selectedTeacherHours
    ? Object.values(selectedTeacherHours.blockMovements).reduce((sum, movements) => sum + movements, 0)
    : 0

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="teacher">Select Teacher</Label>
        <Select value={selectedTeacherId} onValueChange={setSelectedTeacherId}>
          <SelectTrigger>
            <SelectValue placeholder="Select teacher" />
          </SelectTrigger>
          <SelectContent>
            {teachers.map((teacher) => (
              <SelectItem key={teacher.id} value={teacher.id}>
                {teacher.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {selectedTeacher && selectedTeacherHours && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center justify-center space-y-2">
                  <Clock className="h-8 w-8 text-primary" />
                  <h3 className="text-xl font-bold">
                    {Math.round((selectedTeacherHours.totalMinutes / 60) * 10) / 10} hours
                  </h3>
                  <p className="text-sm text-muted-foreground">Total Teaching Time</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center justify-center space-y-2">
                  <BarChart3 className="h-8 w-8 text-primary" />
                  <h3 className="text-xl font-bold">{Math.round((avgMinutesPerDay / 60) * 10) / 10} hours</h3>
                  <p className="text-sm text-muted-foreground">Average Per Day</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center justify-center space-y-2">
                  <BookOpen className="h-8 w-8 text-primary" />
                  <h3 className="text-xl font-bold">{Object.keys(selectedTeacherHours.bySubject).length}</h3>
                  <p className="text-sm text-muted-foreground">Subjects Taught</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center justify-center space-y-2">
                  <Building className="h-8 w-8 text-primary" />
                  <h3 className="text-xl font-bold">{totalBlockMovements}</h3>
                  <p className="text-sm text-muted-foreground">Block Movements</p>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Block Movements by Day</CardTitle>
              <CardDescription>Number of times the teacher changes blocks each day</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Object.entries(selectedTeacherHours.blockMovements).map(([day, movements]) => {
                  const percentage = (movements / 5) * 100 // Assuming max 5 movements per day

                  return (
                    <div key={day} className="space-y-1">
                      <div className="flex justify-between">
                        <span className="capitalize">{day}</span>
                        <span>
                          {movements} {movements === 1 ? "movement" : "movements"}
                        </span>
                      </div>
                      <Progress value={percentage} className="h-2" />
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Time Spent in Each Block</CardTitle>
              <CardDescription>Distribution of teaching time across different blocks</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Object.entries(selectedTeacherHours.byBlock)
                  .sort((a, b) => b[1] - a[1]) // Sort by minutes (descending)
                  .map(([block, minutes]) => {
                    const hours = Math.floor(minutes / 60)
                    const mins = minutes % 60
                    const percentage = (minutes / selectedTeacherHours.totalMinutes) * 100

                    return (
                      <div key={block} className="space-y-1">
                        <div className="flex justify-between">
                          <span>{block}</span>
                          <span>
                            {hours}h {mins}m ({Math.round(percentage)}%)
                          </span>
                        </div>
                        <Progress value={percentage} className="h-2" />
                      </div>
                    )
                  })}
              </div>
            </CardContent>
          </Card>

          {/* Keep the existing cards */}
          <Card>
            <CardHeader>
              <CardTitle>Teaching Load by Day</CardTitle>
              <CardDescription>Distribution of teaching hours across the week</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Object.entries(selectedTeacherHours.byDay).map(([day, minutes]) => {
                  const hours = Math.floor(minutes / 60)
                  const mins = minutes % 60
                  const percentage = (minutes / (8 * 60)) * 100 // Assuming 8-hour school day

                  return (
                    <div key={day} className="space-y-1">
                      <div className="flex justify-between">
                        <span className="capitalize">{day}</span>
                        <span>
                          {hours}h {mins}m
                        </span>
                      </div>
                      <Progress value={percentage} className="h-2" />
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Subject Distribution</CardTitle>
              <CardDescription>Time spent teaching each subject</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Object.entries(selectedTeacherHours.bySubject)
                  .sort((a, b) => b[1] - a[1]) // Sort by minutes (descending)
                  .map(([subject, minutes]) => {
                    const hours = Math.floor(minutes / 60)
                    const mins = minutes % 60
                    const percentage = (minutes / selectedTeacherHours.totalMinutes) * 100

                    return (
                      <div key={subject} className="space-y-1">
                        <div className="flex justify-between">
                          <span>{subject}</span>
                          <span>
                            {hours}h {mins}m
                          </span>
                        </div>
                        <Progress value={percentage} className="h-2" />
                      </div>
                    )
                  })}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Teacher Workload Comparison</CardTitle>
              <CardDescription>How this teacher's workload compares to others</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {teachers
                  .sort((a, b) => (teacherHours[b.id]?.totalMinutes || 0) - (teacherHours[a.id]?.totalMinutes || 0))
                  .map((teacher) => {
                    const teacherMinutes = teacherHours[teacher.id]?.totalMinutes || 0
                    const hours = Math.floor(teacherMinutes / 60)
                    const mins = teacherMinutes % 60
                    const percentage = (teacherMinutes / maxTeachingMinutes) * 100
                    const isSelected = teacher.id === selectedTeacherId

                    return (
                      <div key={teacher.id} className="space-y-1">
                        <div className="flex justify-between">
                          <span className={isSelected ? "font-bold" : ""}>
                            {teacher.name} {isSelected && <Badge variant="outline">Selected</Badge>}
                          </span>
                          <span>
                            {hours}h {mins}m
                          </span>
                        </div>
                        <Progress value={percentage} className={`h-2 ${isSelected ? "bg-primary/20" : "bg-muted"}`} />
                      </div>
                    )
                  })}
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  )
}

function ClassAnalytics({
  schedule,
  classes,
  subjects,
}: { schedule: ScheduleEntry[]; classes: Class[]; subjects: Subject[] }) {
  const [selectedClassId, setSelectedClassId] = useState<string>(classes.length > 0 ? classes[0].id : "")

  // Calculate class statistics
  const classStats: Record<
    string,
    {
      totalMinutes: number
      byDay: Record<string, number>
      bySubject: Record<string, number>
      homeRoomMinutes: number
      specializedVenueMinutes: number
    }
  > = {}

  classes.forEach((classItem) => {
    classStats[classItem.id] = {
      totalMinutes: 0,
      byDay: { monday: 0, tuesday: 0, wednesday: 0, thursday: 0, friday: 0 },
      bySubject: {},
      homeRoomMinutes: 0,
      specializedVenueMinutes: 0,
    }
  })

  // Process schedule to calculate class statistics
  schedule.forEach((entry) => {
    if (entry.isRecess) return // Skip recess entries

    const classId = entry.classId
    if (!classId || !classStats[classId]) return

    // Calculate duration in minutes
    const startTime = entry.startTime.split(":").map(Number)
    const endTime = entry.endTime.split(":").map(Number)
    const durationMinutes = endTime[0] * 60 + endTime[1] - (startTime[0] * 60 + startTime[1])

    // Add to total
    classStats[classId].totalMinutes += durationMinutes

    // Add to day total
    classStats[classId].byDay[entry.day] += durationMinutes

    // Add to subject total
    if (!classStats[classId].bySubject[entry.subjectName]) {
      classStats[classId].bySubject[entry.subjectName] = 0
    }
    classStats[classId].bySubject[entry.subjectName] += durationMinutes

    // Track home room vs specialized venue usage
    if (entry.subjectCategory === "normal") {
      classStats[classId].homeRoomMinutes += durationMinutes
    } else {
      classStats[classId].specializedVenueMinutes += durationMinutes
    }
  })

  // Get selected class data
  const selectedClass = classes.find((c) => c.id === selectedClassId)
  const selectedClassStats = selectedClassId ? classStats[selectedClassId] : null

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="class">Select Class</Label>
        <Select value={selectedClassId} onValueChange={setSelectedClassId}>
          <SelectTrigger>
            <SelectValue placeholder="Select class" />
          </SelectTrigger>
          <SelectContent>
            {classes.map((classItem) => (
              <SelectItem key={classItem.id} value={classItem.id}>
                {classItem.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {selectedClass && selectedClassStats && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center justify-center space-y-2">
                  <Clock className="h-8 w-8 text-primary" />
                  <h3 className="text-xl font-bold">
                    {Math.round((selectedClassStats.totalMinutes / 60) * 10) / 10} hours
                  </h3>
                  <p className="text-sm text-muted-foreground">Total Class Time</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center justify-center space-y-2">
                  <Building className="h-8 w-8 text-primary" />
                  <h3 className="text-xl font-bold">
                    {Math.round((selectedClassStats.homeRoomMinutes / selectedClassStats.totalMinutes) * 100)}%
                  </h3>
                  <p className="text-sm text-muted-foreground">Time in Home Room</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center justify-center space-y-2">
                  <BookOpen className="h-8 w-8 text-primary" />
                  <h3 className="text-xl font-bold">{Object.keys(selectedClassStats.bySubject).length}</h3>
                  <p className="text-sm text-muted-foreground">Subjects</p>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Class Schedule by Day</CardTitle>
              <CardDescription>Distribution of class hours across the week</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Object.entries(selectedClassStats.byDay).map(([day, minutes]) => {
                  const hours = Math.floor(minutes / 60)
                  const mins = minutes % 60
                  const percentage = (minutes / (6 * 60)) * 100 // Assuming 6-hour school day

                  return (
                    <div key={day} className="space-y-1">
                      <div className="flex justify-between">
                        <span className="capitalize">{day}</span>
                        <span>
                          {hours}h {mins}m
                        </span>
                      </div>
                      <Progress value={percentage} className="h-2" />
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Subject Distribution</CardTitle>
              <CardDescription>Time spent on each subject</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Object.entries(selectedClassStats.bySubject)
                  .sort((a, b) => b[1] - a[1]) // Sort by minutes (descending)
                  .map(([subject, minutes]) => {
                    const hours = Math.floor(minutes / 60)
                    const mins = minutes % 60
                    const percentage = (minutes / selectedClassStats.totalMinutes) * 100

                    return (
                      <div key={subject} className="space-y-1">
                        <div className="flex justify-between">
                          <span>{subject}</span>
                          <span>
                            {hours}h {mins}m
                          </span>
                        </div>
                        <Progress value={percentage} className="h-2" />
                      </div>
                    )
                  })}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Venue Usage</CardTitle>
              <CardDescription>Time spent in home room vs. specialized venues</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <div>
                    <h4 className="font-medium">Home Room ({selectedClass.homeRoom})</h4>
                    <p className="text-sm text-muted-foreground">
                      {Math.floor(selectedClassStats.homeRoomMinutes / 60)}h {selectedClassStats.homeRoomMinutes % 60}m
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-lg font-bold">
                      {Math.round((selectedClassStats.homeRoomMinutes / selectedClassStats.totalMinutes) * 100)}%
                    </span>
                  </div>
                </div>
                <Progress
                  value={(selectedClassStats.homeRoomMinutes / selectedClassStats.totalMinutes) * 100}
                  className="h-2"
                />

                <Separator className="my-2" />

                <div className="flex justify-between items-center">
                  <div>
                    <h4 className="font-medium">Specialized Venues</h4>
                    <p className="text-sm text-muted-foreground">
                      {Math.floor(selectedClassStats.specializedVenueMinutes / 60)}h{" "}
                      {selectedClassStats.specializedVenueMinutes % 60}m
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-lg font-bold">
                      {Math.round((selectedClassStats.specializedVenueMinutes / selectedClassStats.totalMinutes) * 100)}
                      %
                    </span>
                  </div>
                </div>
                <Progress
                  value={(selectedClassStats.specializedVenueMinutes / selectedClassStats.totalMinutes) * 100}
                  className="h-2"
                />
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  )
}

function SubjectAnalytics({ schedule, subjects }: { schedule: ScheduleEntry[]; subjects: Subject[] }) {
  // Calculate subject statistics
  const subjectStats: Record<
    string,
    {
      totalMinutes: number
      totalSessions: number
      averageSessionLength: number
      byClass: Record<string, number>
    }
  > = {}

  subjects.forEach((subject) => {
    subjectStats[subject.id] = {
      totalMinutes: 0,
      totalSessions: 0,
      averageSessionLength: 0,
      byClass: {},
    }
  })

  // Process schedule to calculate subject statistics
  schedule.forEach((entry) => {
    if (entry.isRecess) return // Skip recess entries

    const subjectId = entry.subjectId
    if (!subjectId || !subjectStats[subjectId]) return

    // Calculate duration in minutes
    const startTime = entry.startTime.split(":").map(Number)
    const endTime = entry.endTime.split(":").map(Number)
    const durationMinutes = endTime[0] * 60 + endTime[1] - (startTime[0] * 60 + startTime[1])

    // Add to total
    subjectStats[subjectId].totalMinutes += durationMinutes
    subjectStats[subjectId].totalSessions += 1

    // Add to class total
    if (!subjectStats[subjectId].byClass[entry.className]) {
      subjectStats[subjectId].byClass[entry.className] = 0
    }
    subjectStats[subjectId].byClass[entry.className] += durationMinutes
  })

  // Calculate average session length
  Object.values(subjectStats).forEach((stats) => {
    if (stats.totalSessions > 0) {
      stats.averageSessionLength = stats.totalMinutes / stats.totalSessions
    }
  })

  // Find the subject with the most teaching hours for comparison
  const maxSubjectMinutes = Math.max(...Object.values(subjectStats).map((s) => s.totalMinutes || 0), 1)

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Subject Time Distribution</CardTitle>
          <CardDescription>Total teaching time for each subject</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {subjects
              .sort((a, b) => (subjectStats[b.id]?.totalMinutes || 0) - (subjectStats[a.id]?.totalMinutes || 0))
              .map((subject) => {
                const stats = subjectStats[subject.id]
                if (!stats || stats.totalMinutes === 0) return null

                const hours = Math.floor(stats.totalMinutes / 60)
                const mins = stats.totalMinutes % 60
                const percentage = (stats.totalMinutes / maxSubjectMinutes) * 100
                const avgSessionMins = Math.round(stats.averageSessionLength)

                return (
                  <div key={subject.id} className="space-y-1">
                    <div className="flex justify-between">
                      <div>
                        <span className="font-medium">{subject.name}</span>
                        <span className="text-xs text-muted-foreground ml-2">
                          ({stats.totalSessions} sessions, avg {Math.floor(avgSessionMins / 60)}h {avgSessionMins % 60}m
                          each)
                        </span>
                      </div>
                      <span>
                        {hours}h {mins}m
                      </span>
                    </div>
                    <Progress value={percentage} className="h-2" />
                  </div>
                )
              })}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {subjects
          .filter((subject) => (subjectStats[subject.id]?.totalMinutes || 0) > 0)
          .sort((a, b) => (subjectStats[b.id]?.totalMinutes || 0) - (subjectStats[a.id]?.totalMinutes || 0))
          .slice(0, 6) // Show top 6 subjects
          .map((subject) => {
            const stats = subjectStats[subject.id]
            if (!stats) return null

            return (
              <Card key={subject.id}>
                <CardHeader>
                  <CardTitle>{subject.name}</CardTitle>
                  <CardDescription>
                    {Math.floor(stats.totalMinutes / 60)}h {stats.totalMinutes % 60}m total |{stats.totalSessions}{" "}
                    sessions
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <h4 className="text-sm font-medium">Class Distribution</h4>
                    {Object.entries(stats.byClass)
                      .sort((a, b) => b[1] - a[1]) // Sort by minutes (descending)
                      .map(([className, minutes]) => {
                        const percentage = (minutes / stats.totalMinutes) * 100

                        return (
                          <div key={className} className="space-y-1">
                            <div className="flex justify-between text-sm">
                              <span>{className}</span>
                              <span>
                                {Math.floor(minutes / 60)}h {minutes % 60}m
                              </span>
                            </div>
                            <Progress value={percentage} className="h-1.5" />
                          </div>
                        )
                      })}
                  </div>
                </CardContent>
              </Card>
            )
          })}
      </div>
    </div>
  )
}

function VenueAnalytics({ schedule, venues }: { schedule: ScheduleEntry[]; venues: Venue[] }) {
  // Calculate venue statistics
  const venueStats: Record<
    string,
    {
      totalMinutes: number
      utilizationRate: number
      byDay: Record<string, number>
      bySubject: Record<string, number>
    }
  > = {}

  // Initialize stats for all venues
  venues.forEach((venue) => {
    venueStats[venue.id] = {
      totalMinutes: 0,
      utilizationRate: 0,
      byDay: { monday: 0, tuesday: 0, wednesday: 0, thursday: 0, friday: 0 },
      bySubject: {},
    }
  })

  // Also track home rooms
  const homeRoomStats: Record<
    string,
    {
      totalMinutes: number
      byDay: Record<string, number>
    }
  > = {}

  // Process schedule to calculate venue statistics
  schedule.forEach((entry) => {
    if (entry.isRecess) return // Skip recess entries

    // Calculate duration in minutes
    const startTime = entry.startTime.split(":").map(Number)
    const endTime = entry.endTime.split(":").map(Number)
    const durationMinutes = endTime[0] * 60 + endTime[1] - (startTime[0] * 60 + startTime[1])

    if (entry.venueId.startsWith("homeroom-")) {
      // This is a home room
      const homeRoom = entry.venueName

      if (!homeRoomStats[homeRoom]) {
        homeRoomStats[homeRoom] = {
          totalMinutes: 0,
          byDay: { monday: 0, tuesday: 0, wednesday: 0, thursday: 0, friday: 0 },
        }
      }

      homeRoomStats[homeRoom].totalMinutes += durationMinutes
      homeRoomStats[homeRoom].byDay[entry.day] += durationMinutes
    } else {
      // This is a specialized venue
      const venueId = entry.venueId
      if (!venueId || !venueStats[venueId]) return

      // Add to total
      venueStats[venueId].totalMinutes += durationMinutes

      // Add to day total
      venueStats[venueId].byDay[entry.day] += durationMinutes

      // Add to subject total
      if (!venueStats[venueId].bySubject[entry.subjectName]) {
        venueStats[venueId].bySubject[entry.subjectName] = 0
      }
      venueStats[venueId].bySubject[entry.subjectName] += durationMinutes
    }
  })

  // Calculate utilization rate (assuming 8-hour school day, 5 days)
  const totalPossibleMinutes = 8 * 60 * 5 // 8 hours * 60 minutes * 5 days
  Object.values(venueStats).forEach((stats) => {
    stats.utilizationRate = (stats.totalMinutes / totalPossibleMinutes) * 100
  })

  // Find the venue with the highest utilization for comparison
  const maxUtilization = Math.max(...Object.values(venueStats).map((v) => v.utilizationRate || 0), 1)

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Specialized Venue Utilization</CardTitle>
          <CardDescription>How efficiently each venue is being utilized</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {venues
              .sort((a, b) => (venueStats[b.id]?.utilizationRate || 0) - (venueStats[a.id]?.utilizationRate || 0))
              .map((venue) => {
                const stats = venueStats[venue.id]
                if (!stats) return null

                const hours = Math.floor(stats.totalMinutes / 60)
                const mins = stats.totalMinutes % 60
                const utilizationPercentage = Math.round(stats.utilizationRate)

                return (
                  <div key={venue.id} className="space-y-1">
                    <div className="flex justify-between">
                      <div>
                        <span className="font-medium">{venue.name}</span>
                        <Badge variant="outline" className="ml-2">
                          {venue.category}
                        </Badge>
                      </div>
                      <span>
                        {hours}h {mins}m ({utilizationPercentage}% utilized)
                      </span>
                    </div>
                    <Progress value={(stats.utilizationRate / maxUtilization) * 100} className="h-2" />
                  </div>
                )
              })}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Home Room Usage</CardTitle>
          <CardDescription>How much each home room is being used</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Object.entries(homeRoomStats)
              .sort((a, b) => b[1].totalMinutes - a[1].totalMinutes)
              .map(([homeRoom, stats]) => {
                const hours = Math.floor(stats.totalMinutes / 60)
                const mins = stats.totalMinutes % 60
                const utilizationPercentage = Math.round((stats.totalMinutes / totalPossibleMinutes) * 100)

                return (
                  <div key={homeRoom} className="space-y-1">
                    <div className="flex justify-between">
                      <span className="font-medium">{homeRoom}</span>
                      <span>
                        {hours}h {mins}m ({utilizationPercentage}% utilized)
                      </span>
                    </div>
                    <Progress value={(stats.totalMinutes / totalPossibleMinutes) * 100} className="h-2" />
                  </div>
                )
              })}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {venues
          .filter((venue) => (venueStats[venue.id]?.totalMinutes || 0) > 0)
          .sort((a, b) => (venueStats[b.id]?.totalMinutes || 0) - (venueStats[a.id]?.totalMinutes || 0))
          .slice(0, 4) // Show top 4 venues
          .map((venue) => {
            const stats = venueStats[venue.id]
            if (!stats) return null

            return (
              <Card key={venue.id}>
                <CardHeader>
                  <CardTitle>{venue.name}</CardTitle>
                  <CardDescription>
                    {venue.category} | {Math.floor(stats.totalMinutes / 60)}h {stats.totalMinutes % 60}m total
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <h4 className="text-sm font-medium">Daily Usage</h4>
                    {Object.entries(stats.byDay).map(([day, minutes]) => {
                      const percentage = minutes > 0 ? (minutes / (8 * 60)) * 100 : 0 // % of 8-hour day

                      return (
                        <div key={day} className="space-y-1">
                          <div className="flex justify-between text-sm">
                            <span className="capitalize">{day}</span>
                            <span>
                              {Math.floor(minutes / 60)}h {minutes % 60}m
                            </span>
                          </div>
                          <Progress value={percentage} className="h-1.5" />
                        </div>
                      )
                    })}

                    {Object.keys(stats.bySubject).length > 0 && (
                      <>
                        <Separator className="my-2" />
                        <h4 className="text-sm font-medium">Subject Usage</h4>
                        {Object.entries(stats.bySubject)
                          .sort((a, b) => b[1] - a[1]) // Sort by minutes (descending)
                          .slice(0, 3) // Top 3 subjects
                          .map(([subject, minutes]) => {
                            const percentage = (minutes / stats.totalMinutes) * 100

                            return (
                              <div key={subject} className="space-y-1">
                                <div className="flex justify-between text-sm">
                                  <span>{subject}</span>
                                  <span>
                                    {Math.floor(minutes / 60)}h {minutes % 60}m
                                  </span>
                                </div>
                                <Progress value={percentage} className="h-1.5" />
                              </div>
                            )
                          })}
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>
            )
          })}
      </div>
    </div>
  )
}
